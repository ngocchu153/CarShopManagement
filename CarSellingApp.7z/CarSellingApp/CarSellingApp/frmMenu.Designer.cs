﻿namespace CarSellingApp
{
    partial class frmMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnFindCar = new System.Windows.Forms.Button();
            this.btnManageCars = new System.Windows.Forms.Button();
            this.btnSale = new System.Windows.Forms.Button();
            this.btnManageEmployees = new System.Windows.Forms.Button();
            this.btnManageCustomers = new System.Windows.Forms.Button();
            this.btnImportExport = new System.Windows.Forms.Button();
            this.lbMenu = new System.Windows.Forms.Label();
            this.mnsLogout = new System.Windows.Forms.MenuStrip();
            this.logOutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnExportRevenueReport = new System.Windows.Forms.Button();
            this.mnsLogout.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnFindCar
            // 
            this.btnFindCar.Location = new System.Drawing.Point(51, 84);
            this.btnFindCar.Name = "btnFindCar";
            this.btnFindCar.Size = new System.Drawing.Size(102, 55);
            this.btnFindCar.TabIndex = 0;
            this.btnFindCar.Text = "Search Car";
            this.btnFindCar.UseVisualStyleBackColor = true;
            this.btnFindCar.Click += new System.EventHandler(this.btnFindCar_Click);
            // 
            // btnManageCars
            // 
            this.btnManageCars.Location = new System.Drawing.Point(178, 84);
            this.btnManageCars.Name = "btnManageCars";
            this.btnManageCars.Size = new System.Drawing.Size(102, 55);
            this.btnManageCars.TabIndex = 1;
            this.btnManageCars.Text = "Manage Car";
            this.btnManageCars.UseVisualStyleBackColor = true;
            this.btnManageCars.Click += new System.EventHandler(this.btnManageCar_Click);
            // 
            // btnSale
            // 
            this.btnSale.Location = new System.Drawing.Point(51, 156);
            this.btnSale.Name = "btnSale";
            this.btnSale.Size = new System.Drawing.Size(102, 55);
            this.btnSale.TabIndex = 2;
            this.btnSale.Text = "New Order";
            this.btnSale.UseVisualStyleBackColor = true;
            this.btnSale.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnManageEmployees
            // 
            this.btnManageEmployees.Location = new System.Drawing.Point(178, 156);
            this.btnManageEmployees.Name = "btnManageEmployees";
            this.btnManageEmployees.Size = new System.Drawing.Size(102, 55);
            this.btnManageEmployees.TabIndex = 3;
            this.btnManageEmployees.Text = "Manage Employees";
            this.btnManageEmployees.UseVisualStyleBackColor = true;
            this.btnManageEmployees.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnManageCustomers
            // 
            this.btnManageCustomers.Location = new System.Drawing.Point(178, 230);
            this.btnManageCustomers.Name = "btnManageCustomers";
            this.btnManageCustomers.Size = new System.Drawing.Size(102, 58);
            this.btnManageCustomers.TabIndex = 4;
            this.btnManageCustomers.Text = "Manage Customers";
            this.btnManageCustomers.UseVisualStyleBackColor = true;
            this.btnManageCustomers.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnImportExport
            // 
            this.btnImportExport.Location = new System.Drawing.Point(51, 230);
            this.btnImportExport.Name = "btnImportExport";
            this.btnImportExport.Size = new System.Drawing.Size(102, 58);
            this.btnImportExport.TabIndex = 5;
            this.btnImportExport.Text = "Import/Export Cars";
            this.btnImportExport.UseVisualStyleBackColor = true;
            this.btnImportExport.Click += new System.EventHandler(this.button4_Click);
            // 
            // lbMenu
            // 
            this.lbMenu.AutoSize = true;
            this.lbMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMenu.ForeColor = System.Drawing.Color.Blue;
            this.lbMenu.Location = new System.Drawing.Point(116, 36);
            this.lbMenu.Name = "lbMenu";
            this.lbMenu.Size = new System.Drawing.Size(98, 31);
            this.lbMenu.TabIndex = 29;
            this.lbMenu.Text = "MENU";
            // 
            // mnsLogout
            // 
            this.mnsLogout.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.logOutToolStripMenuItem});
            this.mnsLogout.Location = new System.Drawing.Point(0, 0);
            this.mnsLogout.Name = "mnsLogout";
            this.mnsLogout.Size = new System.Drawing.Size(340, 24);
            this.mnsLogout.TabIndex = 30;
            this.mnsLogout.Text = "mnsLogout";
            // 
            // logOutToolStripMenuItem
            // 
            this.logOutToolStripMenuItem.Name = "logOutToolStripMenuItem";
            this.logOutToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.logOutToolStripMenuItem.Text = "Log Out";
            this.logOutToolStripMenuItem.Click += new System.EventHandler(this.logOutToolStripMenuItem_Click);
            // 
            // btnExportRevenueReport
            // 
            this.btnExportRevenueReport.Location = new System.Drawing.Point(112, 304);
            this.btnExportRevenueReport.Name = "btnExportRevenueReport";
            this.btnExportRevenueReport.Size = new System.Drawing.Size(102, 58);
            this.btnExportRevenueReport.TabIndex = 31;
            this.btnExportRevenueReport.Text = "Export Revenue Report";
            this.btnExportRevenueReport.UseVisualStyleBackColor = true;
            this.btnExportRevenueReport.Click += new System.EventHandler(this.btnExportRevenueReport_Click);
            // 
            // frmMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(340, 375);
            this.Controls.Add(this.btnExportRevenueReport);
            this.Controls.Add(this.lbMenu);
            this.Controls.Add(this.btnImportExport);
            this.Controls.Add(this.btnManageCustomers);
            this.Controls.Add(this.btnManageEmployees);
            this.Controls.Add(this.btnSale);
            this.Controls.Add(this.btnManageCars);
            this.Controls.Add(this.btnFindCar);
            this.Controls.Add(this.mnsLogout);
            this.MainMenuStrip = this.mnsLogout;
            this.Name = "frmMenu";
            this.Text = "Menu";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmMenu_FormClosed);
            this.Load += new System.EventHandler(this.frmMenu_Load);
            this.mnsLogout.ResumeLayout(false);
            this.mnsLogout.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnFindCar;
        private System.Windows.Forms.Button btnManageCars;
        private System.Windows.Forms.Button btnSale;
        private System.Windows.Forms.Button btnManageEmployees;
        private System.Windows.Forms.Button btnManageCustomers;
        private System.Windows.Forms.Button btnImportExport;
        private System.Windows.Forms.Label lbMenu;
        private System.Windows.Forms.MenuStrip mnsLogout;
        private System.Windows.Forms.ToolStripMenuItem logOutToolStripMenuItem;
        private System.Windows.Forms.Button btnExportRevenueReport;
    }
}