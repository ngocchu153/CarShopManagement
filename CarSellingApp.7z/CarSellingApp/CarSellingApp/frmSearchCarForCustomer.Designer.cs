﻿namespace CarSellingApp
{
    partial class frmSearchCarForCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBoxFind = new System.Windows.Forms.GroupBox();
            this.rbtbPrice = new System.Windows.Forms.RadioButton();
            this.rbtnCarModel = new System.Windows.Forms.RadioButton();
            this.rbtnCarName = new System.Windows.Forms.RadioButton();
            this.txtKeyword = new System.Windows.Forms.TextBox();
            this.lbKeyword = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.groupBoxResult = new System.Windows.Forms.GroupBox();
            this.dgvResult = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Manufacture = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CarName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.category = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lbSearchCar = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.logOutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBoxFind.SuspendLayout();
            this.groupBoxResult.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResult)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxFind
            // 
            this.groupBoxFind.Controls.Add(this.rbtbPrice);
            this.groupBoxFind.Controls.Add(this.rbtnCarModel);
            this.groupBoxFind.Controls.Add(this.rbtnCarName);
            this.groupBoxFind.Controls.Add(this.txtKeyword);
            this.groupBoxFind.Controls.Add(this.lbKeyword);
            this.groupBoxFind.Controls.Add(this.btnSearch);
            this.groupBoxFind.Location = new System.Drawing.Point(32, 50);
            this.groupBoxFind.Name = "groupBoxFind";
            this.groupBoxFind.Size = new System.Drawing.Size(592, 134);
            this.groupBoxFind.TabIndex = 8;
            this.groupBoxFind.TabStop = false;
            this.groupBoxFind.Text = "Find";
            // 
            // rbtbPrice
            // 
            this.rbtbPrice.AutoSize = true;
            this.rbtbPrice.Location = new System.Drawing.Point(379, 83);
            this.rbtbPrice.Name = "rbtbPrice";
            this.rbtbPrice.Size = new System.Drawing.Size(49, 17);
            this.rbtbPrice.TabIndex = 6;
            this.rbtbPrice.TabStop = true;
            this.rbtbPrice.Text = "Price";
            this.rbtbPrice.UseVisualStyleBackColor = true;
            this.rbtbPrice.CheckedChanged += new System.EventHandler(this.rbtbPrice_CheckedChanged);
            // 
            // rbtnCarModel
            // 
            this.rbtnCarModel.AutoSize = true;
            this.rbtnCarModel.Location = new System.Drawing.Point(270, 83);
            this.rbtnCarModel.Name = "rbtnCarModel";
            this.rbtnCarModel.Size = new System.Drawing.Size(85, 17);
            this.rbtnCarModel.TabIndex = 5;
            this.rbtnCarModel.TabStop = true;
            this.rbtnCarModel.Text = "Manufacture";
            this.rbtnCarModel.UseVisualStyleBackColor = true;
            this.rbtnCarModel.CheckedChanged += new System.EventHandler(this.rbtnCarModel_CheckedChanged);
            // 
            // rbtnCarName
            // 
            this.rbtnCarName.AutoSize = true;
            this.rbtnCarName.Location = new System.Drawing.Point(163, 83);
            this.rbtnCarName.Name = "rbtnCarName";
            this.rbtnCarName.Size = new System.Drawing.Size(72, 17);
            this.rbtnCarName.TabIndex = 4;
            this.rbtnCarName.TabStop = true;
            this.rbtnCarName.Text = "Car Name";
            this.rbtnCarName.UseVisualStyleBackColor = true;
            this.rbtnCarName.CheckedChanged += new System.EventHandler(this.rbtnCarName_CheckedChanged);
            // 
            // txtKeyword
            // 
            this.txtKeyword.Location = new System.Drawing.Point(163, 35);
            this.txtKeyword.Name = "txtKeyword";
            this.txtKeyword.Size = new System.Drawing.Size(283, 20);
            this.txtKeyword.TabIndex = 1;
            // 
            // lbKeyword
            // 
            this.lbKeyword.AutoSize = true;
            this.lbKeyword.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbKeyword.Location = new System.Drawing.Point(51, 32);
            this.lbKeyword.Name = "lbKeyword";
            this.lbKeyword.Size = new System.Drawing.Size(84, 24);
            this.lbKeyword.TabIndex = 0;
            this.lbKeyword.Text = "Keyword";
            // 
            // btnSearch
            // 
            this.btnSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSearch.Location = new System.Drawing.Point(481, 32);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(65, 25);
            this.btnSearch.TabIndex = 2;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // groupBoxResult
            // 
            this.groupBoxResult.Controls.Add(this.dgvResult);
            this.groupBoxResult.Cursor = System.Windows.Forms.Cursors.Hand;
            this.groupBoxResult.Location = new System.Drawing.Point(32, 200);
            this.groupBoxResult.Name = "groupBoxResult";
            this.groupBoxResult.Size = new System.Drawing.Size(595, 228);
            this.groupBoxResult.TabIndex = 9;
            this.groupBoxResult.TabStop = false;
            this.groupBoxResult.Text = "List of Result";
            // 
            // dgvResult
            // 
            this.dgvResult.AllowUserToAddRows = false;
            this.dgvResult.AllowUserToDeleteRows = false;
            this.dgvResult.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvResult.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvResult.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.Manufacture,
            this.CarName,
            this.category,
            this.price});
            this.dgvResult.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dgvResult.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvResult.Location = new System.Drawing.Point(3, 16);
            this.dgvResult.Name = "dgvResult";
            this.dgvResult.ReadOnly = true;
            this.dgvResult.Size = new System.Drawing.Size(589, 209);
            this.dgvResult.TabIndex = 0;
            this.dgvResult.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvResult_CellClick);
            // 
            // ID
            // 
            this.ID.DataPropertyName = "carID";
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            // 
            // Manufacture
            // 
            this.Manufacture.DataPropertyName = "manufactureName";
            this.Manufacture.HeaderText = "Manufacture";
            this.Manufacture.Name = "Manufacture";
            this.Manufacture.ReadOnly = true;
            // 
            // CarName
            // 
            this.CarName.DataPropertyName = "carName";
            this.CarName.HeaderText = "Car Name";
            this.CarName.Name = "CarName";
            this.CarName.ReadOnly = true;
            // 
            // category
            // 
            this.category.DataPropertyName = "category";
            this.category.HeaderText = "Category";
            this.category.Name = "category";
            this.category.ReadOnly = true;
            // 
            // price
            // 
            this.price.DataPropertyName = "price";
            this.price.HeaderText = "Price";
            this.price.Name = "price";
            this.price.ReadOnly = true;
            // 
            // lbSearchCar
            // 
            this.lbSearchCar.AutoSize = true;
            this.lbSearchCar.Font = new System.Drawing.Font("Microsoft Sans Serif", 27F);
            this.lbSearchCar.ForeColor = System.Drawing.Color.Blue;
            this.lbSearchCar.Location = new System.Drawing.Point(225, 7);
            this.lbSearchCar.Name = "lbSearchCar";
            this.lbSearchCar.Size = new System.Drawing.Size(253, 40);
            this.lbSearchCar.TabIndex = 7;
            this.lbSearchCar.Text = "SEARCH CAR";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.logOutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(658, 24);
            this.menuStrip1.TabIndex = 10;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // logOutToolStripMenuItem
            // 
            this.logOutToolStripMenuItem.Name = "logOutToolStripMenuItem";
            this.logOutToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.logOutToolStripMenuItem.Text = "Log out";
            this.logOutToolStripMenuItem.Click += new System.EventHandler(this.logOutToolStripMenuItem_Click);
            // 
            // frmSearchCarForCustomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(658, 434);
            this.Controls.Add(this.groupBoxFind);
            this.Controls.Add(this.groupBoxResult);
            this.Controls.Add(this.lbSearchCar);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmSearchCarForCustomer";
            this.Text = "frmSearchCarForCustomer";
            this.groupBoxFind.ResumeLayout(false);
            this.groupBoxFind.PerformLayout();
            this.groupBoxResult.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvResult)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxFind;
        private System.Windows.Forms.RadioButton rbtbPrice;
        private System.Windows.Forms.RadioButton rbtnCarModel;
        private System.Windows.Forms.RadioButton rbtnCarName;
        private System.Windows.Forms.TextBox txtKeyword;
        private System.Windows.Forms.Label lbKeyword;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.GroupBox groupBoxResult;
        private System.Windows.Forms.DataGridView dgvResult;
        private System.Windows.Forms.Label lbSearchCar;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Manufacture;
        private System.Windows.Forms.DataGridViewTextBoxColumn CarName;
        private System.Windows.Forms.DataGridViewTextBoxColumn category;
        private System.Windows.Forms.DataGridViewTextBoxColumn price;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem logOutToolStripMenuItem;
    }
}