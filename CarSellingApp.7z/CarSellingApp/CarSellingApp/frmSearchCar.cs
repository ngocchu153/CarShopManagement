﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CarSellingApp
{
    public partial class frmSearchCar : Form
    {

        DataGridViewRow row;
        public frmSearchCar()
        {
            InitializeComponent();
        }

        int searchingType = 0;

        public static void connect(SqlConnection cnn)
        {
            string connectionString = "Data Source=DESKTOP-M59GT3U\\SQLEXPRESS; Initial Catalog = car1; Integrated Security=true;";
            cnn.ConnectionString = connectionString;
            cnn.Open();
        }

        public static DataTable SearchByCarName(string carname)
        {
            SqlConnection cnn = new SqlConnection();
            connect(cnn);
            using (SqlCommand cmd = new SqlCommand("SELECT carID,carName,manufactureName,price,quantity,category FROM carsForSale join manufactures on carsForSale.manufactureCode = manufactures.manufactureCode WHERE carName like '%'+ @carName +'%'", cnn))
            {
                cmd.Parameters.AddWithValue("@carname", carname);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
        }
        public static DataTable SearchByManufacture(string manufacture)
        {
            SqlConnection cnn = new SqlConnection();
            connect(cnn);
            using (SqlCommand cmd = new SqlCommand("SELECT carID,carName,manufactureName,price,quantity,category FROM carsForSale join manufactures on carsForSale.manufactureCode = manufactures.manufactureCode WHERE manufactureName like '%'+ @manufacture +'%'", cnn))
            {
                cmd.Parameters.AddWithValue("@manufacture", manufacture);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
        }

        public static DataTable SearchByCategory(string category)
        {
            SqlConnection cnn = new SqlConnection();
            connect(cnn);
            using (SqlCommand cmd = new SqlCommand("SELECT carID,carName,manufactureName,price,quantity,category FROM carsForSale join manufactures on carsForSale.manufactureCode = manufactures.manufactureCode WHERE category like '%'+ @category +'%'", cnn))
            {
                cmd.Parameters.AddWithValue("@category", category);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
        }

        private void btnFind_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtKeyword.TextLength == 0)
                {
                    SqlConnection cnn = new SqlConnection();
                    connect(cnn);
                    using (SqlCommand cmd = new SqlCommand("SELECT carID,carName,manufactureName,price,quantity,category FROM carsForSale join manufactures on carsForSale.manufactureCode = manufactures.manufactureCode", cnn))
                    {
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        dgvResult.DataSource = dt;
                    }
                }
                else
                {
                    if (searchingType == 0)
                        MessageBox.Show("Choose a type to find!");
                    else
                    {

                        switch (searchingType)
                        {
                            case 1:
                                {
                                    dgvResult.DataSource = SearchByCarName(txtKeyword.Text);
                                    break;
                                }
                            case 2:
                                {
                                    dgvResult.DataSource = SearchByManufacture(txtKeyword.Text);
                                    break;
                                }
                            case 3:
                                {
                                    dgvResult.DataSource = SearchByCategory(txtKeyword.Text);
                                    break;
                                }
                        }
                    }

                }
            }
            catch (Exception)
            {
                MessageBox.Show("Not Found! ");
            }
        }

        private void rbtnCarName_CheckedChanged(object sender, EventArgs e)
        {
            if (rbtnCarName.Checked == true)
                searchingType = 1;
        }

        private void rbtnCarModel_CheckedChanged(object sender, EventArgs e)
        {
            if (rbtnCarModel.Checked == true)
                searchingType = 2;
        }

        private void rbtbCategory_CheckedChanged(object sender, EventArgs e)
        {
            if (rbtbCategory.Checked == true)
                searchingType = 3;
        }
        

        private void frmFindCar_Load(object sender, EventArgs e)
        {

        }

        private void dgvResult_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                row = this.dgvResult.Rows[e.RowIndex];
                SqlConnection cnn = new SqlConnection();
                connect(cnn);
                using (SqlCommand cmd = new SqlCommand("SELECT image FROM carsForSale WHERE carName='" + row.Cells["CarName"].Value.ToString() + "'", cnn))
                {
                    if (cmd.ExecuteScalar() != null)
                    {
                        //show picture on pop-up form
                        SqlCommand SCmdCarSpec = new SqlCommand("SELECT * FROM carsSpecification WHERE carID ='" + row.Cells["ID"].Value.ToString() + "'", cnn);
                        SqlDataAdapter da = new SqlDataAdapter(SCmdCarSpec);
                        DataTable dt = new DataTable();
                        da.Fill(dt);

                        using (Form form = new frmCarSpecs(cmd.ExecuteScalar().ToString(),dt))
                        {
                            form.StartPosition = FormStartPosition.CenterScreen;
                            
                            form.ShowDialog();
                        }
                        cnn.Close();
                        return;
                    }
                    else
                        MessageBox.Show("Not Found! ");

                }
            }
        }

        private void txtKeyword_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
