﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CarSellingApp
{
    public partial class frmManageCustomers : Form
    {

        public frmManageCustomers()
        {
            InitializeComponent();
            Display();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection();
            frmSearchCar.connect(connection);
            string s = "Insert into customers(customerName,customerAddress) values (@customerName,@customerAddress)";
            SqlCommand cmd = new SqlCommand(s, connection);
            cmd.Parameters.AddWithValue("@customerName", txtCustomerName.Text);
            cmd.Parameters.AddWithValue("@customerAddress", txtCusAddress.Text);
            cmd.ExecuteNonQuery();
            connection.Close();
            Clear();
            Display();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection();
            frmSearchCar.connect(connection);
            string DelCmd = "Delete from customers where customerID= '" + dataGridView1.CurrentRow.Cells["customerID"].Value.ToString() + "'";
            SqlCommand cmd = new SqlCommand(DelCmd, connection);
            DialogResult result = MessageBox.Show("Do you want to delete?", "Delete", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (result == DialogResult.OK)
                cmd.ExecuteNonQuery();
            connection.Close();
            Display();
            Clear();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection();
            frmSearchCar.connect(connection);
            string UpdCmd = "Update customers set customerName = @customerName, customerAddress = @customerAddress where customerID='" + txtCustomerID.Text + "'";
            SqlCommand cmd = new SqlCommand(UpdCmd, connection);
            cmd.Parameters.AddWithValue("@customerID", Int32.Parse(txtCustomerID.Text));
            cmd.Parameters.AddWithValue("@customerName", txtCustomerName.Text);
            cmd.Parameters.AddWithValue("@customerAddress", txtCusAddress.Text);

            cmd.ExecuteNonQuery();
            connection.Close();
            Display();
            Clear();
        }


        private void backToManagementToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Clear()
        {
            txtCustomerID.Text = "";
            txtCustomerName.Text = "";
            txtCusAddress.Text = "";
        }
         
        private void Display()
        {
            SqlConnection connection = new SqlConnection();
            frmSearchCar.connect(connection);
            DataTable dt = new DataTable();
            SqlCommand cmd = new SqlCommand("Select * from customers", connection);
            SqlDataAdapter adt = new SqlDataAdapter(cmd);
            adt.Fill(dt);

            dataGridView1.DataSource = dt;
            connection.Close();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtCustomerID.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtCustomerName.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            txtCusAddress.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
        }
    }
}
