﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CarSellingApp
{
    public partial class frmImportExportCar : Form
    {
        public frmImportExportCar()
        {
            InitializeComponent();
            Display();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection connection = new SqlConnection();
                frmSearchCar.connect(connection);

                string uptCmd = "update carsForSale set quantity = (quantity + @ImportQuantity - @ExportQuantity) where (quantity + @ImportQuantity - @ExportQuantity) >= 0 and carID = '" + cbCar.SelectedValue + "'";
                SqlCommand cmd = new SqlCommand(uptCmd, connection);
                cmd.Parameters.AddWithValue("@ImportQuantity", int.Parse(txtImportQuantity.Text));
                cmd.Parameters.AddWithValue("@ExportQuantity", int.Parse(txtExportQuantity.Text));

                int verify = cmd.ExecuteNonQuery();
                cmd.ExecuteNonQuery();
                if (verify > 0) MessageBox.Show("Updated! ");
                else MessageBox.Show("Car quantity is not available! ");

                connection.Close();
            }
            catch (SqlException)
            {
                MessageBox.Show("Can not update!");
            }
            finally
            {
                Display();
                Clear();
            }
        }

        private void Display()
        {
            fillDataCBCar();
            txtExportQuantity.Text = txtImportQuantity.Text = "0";
            SqlConnection connection = new SqlConnection();
            frmSearchCar.connect(connection);
            DataTable dt = new DataTable();
            SqlCommand cmd = new SqlCommand("Select carID, carName, quantity from carsForSale", connection);
            SqlDataAdapter adt = new SqlDataAdapter(cmd);
            adt.Fill(dt);

            dgvImportExport.DataSource = dt;
            connection.Close();
        }

        private void Clear()
        {
            cbCar.SelectedIndex=-1 ;
            txtImportQuantity.Text = txtExportQuantity.Text = "0";
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvImportExport.Rows[e.RowIndex];

                cbCar.SelectedValue = row.Cells["carID"].Value.ToString();

            }
        }

        private void frmImportExportCar_Load(object sender, EventArgs e)
        {

        }

        private void fillDataCBCar()
        {
            SqlConnection cnn = new SqlConnection();
            frmSearchCar.connect(cnn);
            DataSet ds = new DataSet();
            try
            {
                SqlCommand cmd = new SqlCommand("select carID, carName from carsForSale", cnn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                cbCar.DisplayMember = "carName";
                cbCar.ValueMember = "carID";
                cbCar.DataSource = ds.Tables[0];

            }
            catch (Exception)
            {
                MessageBox.Show(" ");
            }
            finally
            {
                cbCar.SelectedIndex = -1;
                cbCar.Text = ("-Select a car-");
                cnn.Close();
            }
        }
    }
}
