﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CarSellingApp
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string cnnString = "Data Source=DESKTOP-M59GT3U\\SQLEXPRESS; Initial Catalog = car1; Integrated Security=true;";
            using (SqlConnection conn = new SqlConnection(cnnString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT Username FROM login WHERE Username = @username and Password = @password", conn))
                {
                    if (txtUsername.Text == "user")
                    {
                        this.Hide();
                        frmSearchCarForCustomer frmNewCusSearch = new frmSearchCarForCustomer();
                        frmNewCusSearch.Show();
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("@username", txtUsername.Text);
                        cmd.Parameters.AddWithValue("@password", txtPassword.Text);

                        var res = cmd.ExecuteScalar();

                        if (res != null)
                        {
                            MessageBox.Show("You are login as " + res + " !");

                            this.Hide();
                            frmMenu frmMenu = new frmMenu();
                            frmMenu.Show();
                        }
                        else
                            MessageBox.Show("Login failed!");
                    }
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
