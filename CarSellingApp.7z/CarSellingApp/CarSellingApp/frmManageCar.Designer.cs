﻿namespace CarSellingApp
{
    partial class frmManageCar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmManageCar));
            this.tabCarSpecìication = new System.Windows.Forms.TabPage();
            this.gbListCarSpecs = new System.Windows.Forms.GroupBox();
            this.dgvCarSpecs = new System.Windows.Forms.DataGridView();
            this.carID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.doorsNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.transmissionType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.seatingCapacity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productYear = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.engineType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gbCarSpecs = new System.Windows.Forms.GroupBox();
            this.txtEngineType = new System.Windows.Forms.TextBox();
            this.txtDoorsNumber = new System.Windows.Forms.TextBox();
            this.lbDoorsNumber = new System.Windows.Forms.Label();
            this.txtProductYear = new System.Windows.Forms.TextBox();
            this.lbProductYear = new System.Windows.Forms.Label();
            this.txtSeatingCapacity = new System.Windows.Forms.TextBox();
            this.lbSeatingCapacity = new System.Windows.Forms.Label();
            this.txtTransmissionType = new System.Windows.Forms.TextBox();
            this.txtCarSpecsID = new System.Windows.Forms.TextBox();
            this.lbTransmissionType = new System.Windows.Forms.Label();
            this.lbEngineType = new System.Windows.Forms.Label();
            this.lbCarSpecsID = new System.Windows.Forms.Label();
            this.gbCarSpecsFunction = new System.Windows.Forms.GroupBox();
            this.btnDeleteCarSpecs = new System.Windows.Forms.Button();
            this.btnAddCarSpecs = new System.Windows.Forms.Button();
            this.btnUpdateCarSpecs = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabCar = new System.Windows.Forms.TabPage();
            this.btnClear = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.btnDeleteCar = new System.Windows.Forms.Button();
            this.btnAddCar = new System.Windows.Forms.Button();
            this.btnUpdateCar = new System.Windows.Forms.Button();
            this.groupBoxResult = new System.Windows.Forms.GroupBox();
            this.dgvResult = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CarName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.category = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Manufacture = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Image = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gbCarInfomation = new System.Windows.Forms.GroupBox();
            this.txtImageLink = new System.Windows.Forms.TextBox();
            this.cbManufacture = new System.Windows.Forms.ComboBox();
            this.btnChooseImage = new System.Windows.Forms.Button();
            this.txtCarName = new System.Windows.Forms.TextBox();
            this.lbCarName = new System.Windows.Forms.Label();
            this.txtQuantity = new System.Windows.Forms.TextBox();
            this.lbQuantity = new System.Windows.Forms.Label();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.lbPrice = new System.Windows.Forms.Label();
            this.txtCategory = new System.Windows.Forms.TextBox();
            this.txtCarID = new System.Windows.Forms.TextBox();
            this.lbManufacture = new System.Windows.Forms.Label();
            this.lbCategory = new System.Windows.Forms.Label();
            this.lbImage = new System.Windows.Forms.Label();
            this.lbCarID = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tabManufacture = new System.Windows.Forms.TabPage();
            this.gbFunctions = new System.Windows.Forms.GroupBox();
            this.btnDeleteManufacture = new System.Windows.Forms.Button();
            this.btnAddManufacture = new System.Windows.Forms.Button();
            this.btnUpdateManufacture = new System.Windows.Forms.Button();
            this.gbManuInfo = new System.Windows.Forms.GroupBox();
            this.txtManuCode = new System.Windows.Forms.TextBox();
            this.txtManuName = new System.Windows.Forms.TextBox();
            this.lbManufactureName = new System.Windows.Forms.Label();
            this.lbManufactureCode = new System.Windows.Forms.Label();
            this.lbManageManufacture = new System.Windows.Forms.Label();
            this.gbManufacture = new System.Windows.Forms.GroupBox();
            this.dgvManufacture = new System.Windows.Forms.DataGridView();
            this.code = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabCarSpecìication.SuspendLayout();
            this.gbListCarSpecs.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCarSpecs)).BeginInit();
            this.gbCarSpecs.SuspendLayout();
            this.gbCarSpecsFunction.SuspendLayout();
            this.tabControl.SuspendLayout();
            this.tabCar.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBoxResult.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResult)).BeginInit();
            this.gbCarInfomation.SuspendLayout();
            this.tabManufacture.SuspendLayout();
            this.gbFunctions.SuspendLayout();
            this.gbManuInfo.SuspendLayout();
            this.gbManufacture.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvManufacture)).BeginInit();
            this.SuspendLayout();
            // 
            // tabCarSpecìication
            // 
            this.tabCarSpecìication.BackColor = System.Drawing.SystemColors.Control;
            this.tabCarSpecìication.Controls.Add(this.gbListCarSpecs);
            this.tabCarSpecìication.Controls.Add(this.gbCarSpecs);
            this.tabCarSpecìication.Controls.Add(this.gbCarSpecsFunction);
            this.tabCarSpecìication.Controls.Add(this.label3);
            resources.ApplyResources(this.tabCarSpecìication, "tabCarSpecìication");
            this.tabCarSpecìication.Name = "tabCarSpecìication";
            // 
            // gbListCarSpecs
            // 
            this.gbListCarSpecs.Controls.Add(this.dgvCarSpecs);
            this.gbListCarSpecs.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.gbListCarSpecs, "gbListCarSpecs");
            this.gbListCarSpecs.Name = "gbListCarSpecs";
            this.gbListCarSpecs.TabStop = false;
            // 
            // dgvCarSpecs
            // 
            this.dgvCarSpecs.AllowUserToAddRows = false;
            this.dgvCarSpecs.AllowUserToDeleteRows = false;
            this.dgvCarSpecs.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvCarSpecs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCarSpecs.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.carID,
            this.doorsNumber,
            this.transmissionType,
            this.seatingCapacity,
            this.productYear,
            this.engineType});
            this.dgvCarSpecs.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.dgvCarSpecs, "dgvCarSpecs");
            this.dgvCarSpecs.Name = "dgvCarSpecs";
            this.dgvCarSpecs.ReadOnly = true;
            this.dgvCarSpecs.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCarSpecs_CellClick);
            // 
            // carID
            // 
            this.carID.DataPropertyName = "carID";
            resources.ApplyResources(this.carID, "carID");
            this.carID.Name = "carID";
            this.carID.ReadOnly = true;
            // 
            // doorsNumber
            // 
            this.doorsNumber.DataPropertyName = "doorsNumber";
            resources.ApplyResources(this.doorsNumber, "doorsNumber");
            this.doorsNumber.Name = "doorsNumber";
            this.doorsNumber.ReadOnly = true;
            // 
            // transmissionType
            // 
            this.transmissionType.DataPropertyName = "transmissionType";
            resources.ApplyResources(this.transmissionType, "transmissionType");
            this.transmissionType.Name = "transmissionType";
            this.transmissionType.ReadOnly = true;
            // 
            // seatingCapacity
            // 
            this.seatingCapacity.DataPropertyName = "seatingCapacity";
            resources.ApplyResources(this.seatingCapacity, "seatingCapacity");
            this.seatingCapacity.Name = "seatingCapacity";
            this.seatingCapacity.ReadOnly = true;
            // 
            // productYear
            // 
            this.productYear.DataPropertyName = "productYear";
            resources.ApplyResources(this.productYear, "productYear");
            this.productYear.Name = "productYear";
            this.productYear.ReadOnly = true;
            // 
            // engineType
            // 
            this.engineType.DataPropertyName = "engineType";
            resources.ApplyResources(this.engineType, "engineType");
            this.engineType.Name = "engineType";
            this.engineType.ReadOnly = true;
            // 
            // gbCarSpecs
            // 
            this.gbCarSpecs.Controls.Add(this.txtEngineType);
            this.gbCarSpecs.Controls.Add(this.txtDoorsNumber);
            this.gbCarSpecs.Controls.Add(this.lbDoorsNumber);
            this.gbCarSpecs.Controls.Add(this.txtProductYear);
            this.gbCarSpecs.Controls.Add(this.lbProductYear);
            this.gbCarSpecs.Controls.Add(this.txtSeatingCapacity);
            this.gbCarSpecs.Controls.Add(this.lbSeatingCapacity);
            this.gbCarSpecs.Controls.Add(this.txtTransmissionType);
            this.gbCarSpecs.Controls.Add(this.txtCarSpecsID);
            this.gbCarSpecs.Controls.Add(this.lbTransmissionType);
            this.gbCarSpecs.Controls.Add(this.lbEngineType);
            this.gbCarSpecs.Controls.Add(this.lbCarSpecsID);
            resources.ApplyResources(this.gbCarSpecs, "gbCarSpecs");
            this.gbCarSpecs.Name = "gbCarSpecs";
            this.gbCarSpecs.TabStop = false;
            // 
            // txtEngineType
            // 
            resources.ApplyResources(this.txtEngineType, "txtEngineType");
            this.txtEngineType.Name = "txtEngineType";
            // 
            // txtDoorsNumber
            // 
            resources.ApplyResources(this.txtDoorsNumber, "txtDoorsNumber");
            this.txtDoorsNumber.Name = "txtDoorsNumber";
            // 
            // lbDoorsNumber
            // 
            resources.ApplyResources(this.lbDoorsNumber, "lbDoorsNumber");
            this.lbDoorsNumber.Name = "lbDoorsNumber";
            // 
            // txtProductYear
            // 
            resources.ApplyResources(this.txtProductYear, "txtProductYear");
            this.txtProductYear.Name = "txtProductYear";
            // 
            // lbProductYear
            // 
            resources.ApplyResources(this.lbProductYear, "lbProductYear");
            this.lbProductYear.Name = "lbProductYear";
            // 
            // txtSeatingCapacity
            // 
            resources.ApplyResources(this.txtSeatingCapacity, "txtSeatingCapacity");
            this.txtSeatingCapacity.Name = "txtSeatingCapacity";
            // 
            // lbSeatingCapacity
            // 
            resources.ApplyResources(this.lbSeatingCapacity, "lbSeatingCapacity");
            this.lbSeatingCapacity.Name = "lbSeatingCapacity";
            // 
            // txtTransmissionType
            // 
            resources.ApplyResources(this.txtTransmissionType, "txtTransmissionType");
            this.txtTransmissionType.Name = "txtTransmissionType";
            // 
            // txtCarSpecsID
            // 
            this.txtCarSpecsID.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            resources.ApplyResources(this.txtCarSpecsID, "txtCarSpecsID");
            this.txtCarSpecsID.Name = "txtCarSpecsID";
            this.txtCarSpecsID.ReadOnly = true;
            // 
            // lbTransmissionType
            // 
            resources.ApplyResources(this.lbTransmissionType, "lbTransmissionType");
            this.lbTransmissionType.Name = "lbTransmissionType";
            // 
            // lbEngineType
            // 
            resources.ApplyResources(this.lbEngineType, "lbEngineType");
            this.lbEngineType.Name = "lbEngineType";
            // 
            // lbCarSpecsID
            // 
            resources.ApplyResources(this.lbCarSpecsID, "lbCarSpecsID");
            this.lbCarSpecsID.Name = "lbCarSpecsID";
            // 
            // gbCarSpecsFunction
            // 
            this.gbCarSpecsFunction.Controls.Add(this.btnDeleteCarSpecs);
            this.gbCarSpecsFunction.Controls.Add(this.btnAddCarSpecs);
            this.gbCarSpecsFunction.Controls.Add(this.btnUpdateCarSpecs);
            resources.ApplyResources(this.gbCarSpecsFunction, "gbCarSpecsFunction");
            this.gbCarSpecsFunction.Name = "gbCarSpecsFunction";
            this.gbCarSpecsFunction.TabStop = false;
            // 
            // btnDeleteCarSpecs
            // 
            resources.ApplyResources(this.btnDeleteCarSpecs, "btnDeleteCarSpecs");
            this.btnDeleteCarSpecs.Name = "btnDeleteCarSpecs";
            this.btnDeleteCarSpecs.UseVisualStyleBackColor = true;
            this.btnDeleteCarSpecs.Click += new System.EventHandler(this.btnDeleteCarSpecs_Click);
            // 
            // btnAddCarSpecs
            // 
            resources.ApplyResources(this.btnAddCarSpecs, "btnAddCarSpecs");
            this.btnAddCarSpecs.Name = "btnAddCarSpecs";
            this.btnAddCarSpecs.UseVisualStyleBackColor = true;
            this.btnAddCarSpecs.Click += new System.EventHandler(this.btnAddCarSpecs_Click);
            // 
            // btnUpdateCarSpecs
            // 
            resources.ApplyResources(this.btnUpdateCarSpecs, "btnUpdateCarSpecs");
            this.btnUpdateCarSpecs.Name = "btnUpdateCarSpecs";
            this.btnUpdateCarSpecs.UseVisualStyleBackColor = true;
            this.btnUpdateCarSpecs.Click += new System.EventHandler(this.btnUpdateCarSpecs_Click);
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.ForeColor = System.Drawing.Color.Blue;
            this.label3.Name = "label3";
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabCar);
            this.tabControl.Controls.Add(this.tabManufacture);
            this.tabControl.Controls.Add(this.tabCarSpecìication);
            resources.ApplyResources(this.tabControl, "tabControl");
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            // 
            // tabCar
            // 
            this.tabCar.BackColor = System.Drawing.SystemColors.Control;
            this.tabCar.Controls.Add(this.btnClear);
            this.tabCar.Controls.Add(this.groupBox1);
            this.tabCar.Controls.Add(this.groupBoxResult);
            this.tabCar.Controls.Add(this.gbCarInfomation);
            this.tabCar.Controls.Add(this.label4);
            resources.ApplyResources(this.tabCar, "tabCar");
            this.tabCar.Name = "tabCar";
            // 
            // btnClear
            // 
            resources.ApplyResources(this.btnClear, "btnClear");
            this.btnClear.Name = "btnClear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.btnDeleteCar);
            this.groupBox1.Controls.Add(this.btnAddCar);
            this.groupBox1.Controls.Add(this.btnUpdateCar);
            resources.ApplyResources(this.groupBox1, "groupBox1");
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.TabStop = false;
            // 
            // button1
            // 
            resources.ApplyResources(this.button1, "button1");
            this.button1.Name = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnDeleteCar
            // 
            resources.ApplyResources(this.btnDeleteCar, "btnDeleteCar");
            this.btnDeleteCar.Name = "btnDeleteCar";
            this.btnDeleteCar.UseVisualStyleBackColor = true;
            this.btnDeleteCar.Click += new System.EventHandler(this.btnDeleteCar_Click);
            // 
            // btnAddCar
            // 
            resources.ApplyResources(this.btnAddCar, "btnAddCar");
            this.btnAddCar.Name = "btnAddCar";
            this.btnAddCar.UseVisualStyleBackColor = true;
            this.btnAddCar.Click += new System.EventHandler(this.btnAddCar_Click);
            // 
            // btnUpdateCar
            // 
            resources.ApplyResources(this.btnUpdateCar, "btnUpdateCar");
            this.btnUpdateCar.Name = "btnUpdateCar";
            this.btnUpdateCar.UseVisualStyleBackColor = true;
            this.btnUpdateCar.Click += new System.EventHandler(this.btnUpdateCar_Click);
            // 
            // groupBoxResult
            // 
            this.groupBoxResult.Controls.Add(this.dgvResult);
            this.groupBoxResult.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.groupBoxResult, "groupBoxResult");
            this.groupBoxResult.Name = "groupBoxResult";
            this.groupBoxResult.TabStop = false;
            // 
            // dgvResult
            // 
            this.dgvResult.AllowUserToAddRows = false;
            this.dgvResult.AllowUserToDeleteRows = false;
            this.dgvResult.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvResult.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvResult.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.CarName,
            this.category,
            this.Manufacture,
            this.price,
            this.quantity,
            this.Image});
            this.dgvResult.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.dgvResult, "dgvResult");
            this.dgvResult.Name = "dgvResult";
            this.dgvResult.ReadOnly = true;
            this.dgvResult.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvResult_CellClick);
            // 
            // ID
            // 
            this.ID.DataPropertyName = "carID";
            resources.ApplyResources(this.ID, "ID");
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            // 
            // CarName
            // 
            this.CarName.DataPropertyName = "carName";
            resources.ApplyResources(this.CarName, "CarName");
            this.CarName.Name = "CarName";
            this.CarName.ReadOnly = true;
            // 
            // category
            // 
            this.category.DataPropertyName = "category";
            resources.ApplyResources(this.category, "category");
            this.category.Name = "category";
            this.category.ReadOnly = true;
            // 
            // Manufacture
            // 
            this.Manufacture.DataPropertyName = "manufactureName";
            resources.ApplyResources(this.Manufacture, "Manufacture");
            this.Manufacture.Name = "Manufacture";
            this.Manufacture.ReadOnly = true;
            // 
            // price
            // 
            this.price.DataPropertyName = "price";
            resources.ApplyResources(this.price, "price");
            this.price.Name = "price";
            this.price.ReadOnly = true;
            // 
            // quantity
            // 
            this.quantity.DataPropertyName = "quantity";
            resources.ApplyResources(this.quantity, "quantity");
            this.quantity.Name = "quantity";
            this.quantity.ReadOnly = true;
            // 
            // Image
            // 
            this.Image.DataPropertyName = "image";
            resources.ApplyResources(this.Image, "Image");
            this.Image.Name = "Image";
            this.Image.ReadOnly = true;
            // 
            // gbCarInfomation
            // 
            this.gbCarInfomation.Controls.Add(this.txtImageLink);
            this.gbCarInfomation.Controls.Add(this.cbManufacture);
            this.gbCarInfomation.Controls.Add(this.btnChooseImage);
            this.gbCarInfomation.Controls.Add(this.txtCarName);
            this.gbCarInfomation.Controls.Add(this.lbCarName);
            this.gbCarInfomation.Controls.Add(this.txtQuantity);
            this.gbCarInfomation.Controls.Add(this.lbQuantity);
            this.gbCarInfomation.Controls.Add(this.txtPrice);
            this.gbCarInfomation.Controls.Add(this.lbPrice);
            this.gbCarInfomation.Controls.Add(this.txtCategory);
            this.gbCarInfomation.Controls.Add(this.txtCarID);
            this.gbCarInfomation.Controls.Add(this.lbManufacture);
            this.gbCarInfomation.Controls.Add(this.lbCategory);
            this.gbCarInfomation.Controls.Add(this.lbImage);
            this.gbCarInfomation.Controls.Add(this.lbCarID);
            resources.ApplyResources(this.gbCarInfomation, "gbCarInfomation");
            this.gbCarInfomation.Name = "gbCarInfomation";
            this.gbCarInfomation.TabStop = false;
            this.gbCarInfomation.Enter += new System.EventHandler(this.gbCarInfomation_Enter);
            // 
            // txtImageLink
            // 
            resources.ApplyResources(this.txtImageLink, "txtImageLink");
            this.txtImageLink.Name = "txtImageLink";
            // 
            // cbManufacture
            // 
            this.cbManufacture.FormattingEnabled = true;
            resources.ApplyResources(this.cbManufacture, "cbManufacture");
            this.cbManufacture.Name = "cbManufacture";
            // 
            // btnChooseImage
            // 
            resources.ApplyResources(this.btnChooseImage, "btnChooseImage");
            this.btnChooseImage.Name = "btnChooseImage";
            this.btnChooseImage.UseVisualStyleBackColor = true;
            this.btnChooseImage.Click += new System.EventHandler(this.btnChooseImage_Click);
            // 
            // txtCarName
            // 
            resources.ApplyResources(this.txtCarName, "txtCarName");
            this.txtCarName.Name = "txtCarName";
            // 
            // lbCarName
            // 
            resources.ApplyResources(this.lbCarName, "lbCarName");
            this.lbCarName.Name = "lbCarName";
            // 
            // txtQuantity
            // 
            resources.ApplyResources(this.txtQuantity, "txtQuantity");
            this.txtQuantity.Name = "txtQuantity";
            // 
            // lbQuantity
            // 
            resources.ApplyResources(this.lbQuantity, "lbQuantity");
            this.lbQuantity.Name = "lbQuantity";
            // 
            // txtPrice
            // 
            resources.ApplyResources(this.txtPrice, "txtPrice");
            this.txtPrice.Name = "txtPrice";
            // 
            // lbPrice
            // 
            resources.ApplyResources(this.lbPrice, "lbPrice");
            this.lbPrice.Name = "lbPrice";
            // 
            // txtCategory
            // 
            resources.ApplyResources(this.txtCategory, "txtCategory");
            this.txtCategory.Name = "txtCategory";
            // 
            // txtCarID
            // 
            this.txtCarID.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            resources.ApplyResources(this.txtCarID, "txtCarID");
            this.txtCarID.Name = "txtCarID";
            this.txtCarID.ReadOnly = true;
            // 
            // lbManufacture
            // 
            resources.ApplyResources(this.lbManufacture, "lbManufacture");
            this.lbManufacture.Name = "lbManufacture";
            // 
            // lbCategory
            // 
            resources.ApplyResources(this.lbCategory, "lbCategory");
            this.lbCategory.Name = "lbCategory";
            // 
            // lbImage
            // 
            resources.ApplyResources(this.lbImage, "lbImage");
            this.lbImage.Name = "lbImage";
            // 
            // lbCarID
            // 
            resources.ApplyResources(this.lbCarID, "lbCarID");
            this.lbCarID.Name = "lbCarID";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.ForeColor = System.Drawing.Color.Blue;
            this.label4.Name = "label4";
            // 
            // tabManufacture
            // 
            this.tabManufacture.BackColor = System.Drawing.SystemColors.Control;
            this.tabManufacture.Controls.Add(this.gbFunctions);
            this.tabManufacture.Controls.Add(this.gbManuInfo);
            this.tabManufacture.Controls.Add(this.lbManageManufacture);
            this.tabManufacture.Controls.Add(this.gbManufacture);
            resources.ApplyResources(this.tabManufacture, "tabManufacture");
            this.tabManufacture.Name = "tabManufacture";
            // 
            // gbFunctions
            // 
            this.gbFunctions.Controls.Add(this.btnDeleteManufacture);
            this.gbFunctions.Controls.Add(this.btnAddManufacture);
            this.gbFunctions.Controls.Add(this.btnUpdateManufacture);
            resources.ApplyResources(this.gbFunctions, "gbFunctions");
            this.gbFunctions.Name = "gbFunctions";
            this.gbFunctions.TabStop = false;
            // 
            // btnDeleteManufacture
            // 
            resources.ApplyResources(this.btnDeleteManufacture, "btnDeleteManufacture");
            this.btnDeleteManufacture.Name = "btnDeleteManufacture";
            this.btnDeleteManufacture.UseVisualStyleBackColor = true;
            this.btnDeleteManufacture.Click += new System.EventHandler(this.btnDeleteManufacture_Click);
            // 
            // btnAddManufacture
            // 
            resources.ApplyResources(this.btnAddManufacture, "btnAddManufacture");
            this.btnAddManufacture.Name = "btnAddManufacture";
            this.btnAddManufacture.UseVisualStyleBackColor = true;
            this.btnAddManufacture.Click += new System.EventHandler(this.btnAddManufacture_Click);
            // 
            // btnUpdateManufacture
            // 
            resources.ApplyResources(this.btnUpdateManufacture, "btnUpdateManufacture");
            this.btnUpdateManufacture.Name = "btnUpdateManufacture";
            this.btnUpdateManufacture.UseVisualStyleBackColor = true;
            this.btnUpdateManufacture.Click += new System.EventHandler(this.btnUpdateManufacture_Click);
            // 
            // gbManuInfo
            // 
            this.gbManuInfo.Controls.Add(this.txtManuCode);
            this.gbManuInfo.Controls.Add(this.txtManuName);
            this.gbManuInfo.Controls.Add(this.lbManufactureName);
            this.gbManuInfo.Controls.Add(this.lbManufactureCode);
            resources.ApplyResources(this.gbManuInfo, "gbManuInfo");
            this.gbManuInfo.Name = "gbManuInfo";
            this.gbManuInfo.TabStop = false;
            // 
            // txtManuCode
            // 
            resources.ApplyResources(this.txtManuCode, "txtManuCode");
            this.txtManuCode.Name = "txtManuCode";
            // 
            // txtManuName
            // 
            resources.ApplyResources(this.txtManuName, "txtManuName");
            this.txtManuName.Name = "txtManuName";
            // 
            // lbManufactureName
            // 
            resources.ApplyResources(this.lbManufactureName, "lbManufactureName");
            this.lbManufactureName.Name = "lbManufactureName";
            // 
            // lbManufactureCode
            // 
            resources.ApplyResources(this.lbManufactureCode, "lbManufactureCode");
            this.lbManufactureCode.Name = "lbManufactureCode";
            // 
            // lbManageManufacture
            // 
            resources.ApplyResources(this.lbManageManufacture, "lbManageManufacture");
            this.lbManageManufacture.ForeColor = System.Drawing.Color.Blue;
            this.lbManageManufacture.Name = "lbManageManufacture";
            this.lbManageManufacture.Click += new System.EventHandler(this.lbManageManufacture_Click);
            // 
            // gbManufacture
            // 
            this.gbManufacture.Controls.Add(this.dgvManufacture);
            resources.ApplyResources(this.gbManufacture, "gbManufacture");
            this.gbManufacture.Name = "gbManufacture";
            this.gbManufacture.TabStop = false;
            // 
            // dgvManufacture
            // 
            this.dgvManufacture.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvManufacture.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvManufacture.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.code,
            this.name});
            resources.ApplyResources(this.dgvManufacture, "dgvManufacture");
            this.dgvManufacture.Name = "dgvManufacture";
            this.dgvManufacture.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvManufacture_CellClick);
            // 
            // code
            // 
            this.code.DataPropertyName = "manufactureCode";
            resources.ApplyResources(this.code, "code");
            this.code.Name = "code";
            // 
            // name
            // 
            this.name.DataPropertyName = "manufactureName";
            resources.ApplyResources(this.name, "name");
            this.name.Name = "name";
            // 
            // frmManageCar
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tabControl);
            this.MaximizeBox = false;
            this.Name = "frmManageCar";
            this.tabCarSpecìication.ResumeLayout(false);
            this.tabCarSpecìication.PerformLayout();
            this.gbListCarSpecs.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCarSpecs)).EndInit();
            this.gbCarSpecs.ResumeLayout(false);
            this.gbCarSpecs.PerformLayout();
            this.gbCarSpecsFunction.ResumeLayout(false);
            this.tabControl.ResumeLayout(false);
            this.tabCar.ResumeLayout(false);
            this.tabCar.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBoxResult.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvResult)).EndInit();
            this.gbCarInfomation.ResumeLayout(false);
            this.gbCarInfomation.PerformLayout();
            this.tabManufacture.ResumeLayout(false);
            this.tabManufacture.PerformLayout();
            this.gbFunctions.ResumeLayout(false);
            this.gbManuInfo.ResumeLayout(false);
            this.gbManuInfo.PerformLayout();
            this.gbManufacture.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvManufacture)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage tabCarSpecìication;
        private System.Windows.Forms.GroupBox gbCarSpecsFunction;
        private System.Windows.Forms.Button btnDeleteCarSpecs;
        private System.Windows.Forms.Button btnAddCarSpecs;
        private System.Windows.Forms.Button btnUpdateCarSpecs;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabCar;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnDeleteCar;
        private System.Windows.Forms.Button btnAddCar;
        private System.Windows.Forms.Button btnUpdateCar;
        private System.Windows.Forms.GroupBox groupBoxResult;
        private System.Windows.Forms.DataGridView dgvResult;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn CarName;
        private System.Windows.Forms.DataGridViewTextBoxColumn category;
        private System.Windows.Forms.DataGridViewTextBoxColumn Manufacture;
        private System.Windows.Forms.DataGridViewTextBoxColumn price;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn Image;
        private System.Windows.Forms.GroupBox gbCarInfomation;
        private System.Windows.Forms.TextBox txtImageLink;
        private System.Windows.Forms.ComboBox cbManufacture;
        private System.Windows.Forms.Button btnChooseImage;
        private System.Windows.Forms.TextBox txtCarName;
        private System.Windows.Forms.Label lbCarName;
        private System.Windows.Forms.TextBox txtQuantity;
        private System.Windows.Forms.Label lbQuantity;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.Label lbPrice;
        private System.Windows.Forms.TextBox txtCategory;
        private System.Windows.Forms.TextBox txtCarID;
        private System.Windows.Forms.Label lbManufacture;
        private System.Windows.Forms.Label lbCategory;
        private System.Windows.Forms.Label lbImage;
        private System.Windows.Forms.Label lbCarID;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TabPage tabManufacture;
        private System.Windows.Forms.GroupBox gbFunctions;
        private System.Windows.Forms.Button btnDeleteManufacture;
        private System.Windows.Forms.Button btnAddManufacture;
        private System.Windows.Forms.Button btnUpdateManufacture;
        private System.Windows.Forms.GroupBox gbManuInfo;
        private System.Windows.Forms.TextBox txtManuCode;
        private System.Windows.Forms.TextBox txtManuName;
        private System.Windows.Forms.Label lbManufactureName;
        private System.Windows.Forms.Label lbManufactureCode;
        private System.Windows.Forms.Label lbManageManufacture;
        private System.Windows.Forms.GroupBox gbManufacture;
        private System.Windows.Forms.DataGridView dgvManufacture;
        private System.Windows.Forms.DataGridViewTextBoxColumn code;
        private System.Windows.Forms.DataGridViewTextBoxColumn name;
        private System.Windows.Forms.GroupBox gbListCarSpecs;
        private System.Windows.Forms.DataGridView dgvCarSpecs;
        private System.Windows.Forms.GroupBox gbCarSpecs;
        private System.Windows.Forms.TextBox txtEngineType;
        private System.Windows.Forms.TextBox txtDoorsNumber;
        private System.Windows.Forms.Label lbDoorsNumber;
        private System.Windows.Forms.TextBox txtProductYear;
        private System.Windows.Forms.Label lbProductYear;
        private System.Windows.Forms.TextBox txtSeatingCapacity;
        private System.Windows.Forms.Label lbSeatingCapacity;
        private System.Windows.Forms.TextBox txtTransmissionType;
        private System.Windows.Forms.TextBox txtCarSpecsID;
        private System.Windows.Forms.Label lbTransmissionType;
        private System.Windows.Forms.Label lbEngineType;
        private System.Windows.Forms.Label lbCarSpecsID;
        private System.Windows.Forms.DataGridViewTextBoxColumn carID;
        private System.Windows.Forms.DataGridViewTextBoxColumn doorsNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn transmissionType;
        private System.Windows.Forms.DataGridViewTextBoxColumn seatingCapacity;
        private System.Windows.Forms.DataGridViewTextBoxColumn productYear;
        private System.Windows.Forms.DataGridViewTextBoxColumn engineType;
        private System.Windows.Forms.Button button1;
    }
}