﻿namespace CarSellingApp
{
    partial class frmCarSpecs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pbCarSpecs = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lbDoorsDetail = new System.Windows.Forms.Label();
            this.lbTranssionsTypeDetail = new System.Windows.Forms.Label();
            this.lbSeatingCapacityDetail = new System.Windows.Forms.Label();
            this.lbProductYearDetail = new System.Windows.Forms.Label();
            this.lbEngineTypeDetail = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbCarSpecs)).BeginInit();
            this.SuspendLayout();
            // 
            // pbCarSpecs
            // 
            this.pbCarSpecs.Location = new System.Drawing.Point(57, 40);
            this.pbCarSpecs.Name = "pbCarSpecs";
            this.pbCarSpecs.Size = new System.Drawing.Size(461, 255);
            this.pbCarSpecs.TabIndex = 0;
            this.pbCarSpecs.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(188, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label2.Location = new System.Drawing.Point(75, 298);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Doors number:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label3.Location = new System.Drawing.Point(75, 320);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 17);
            this.label3.TabIndex = 3;
            this.label3.Text = "Transmission type:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label4.Location = new System.Drawing.Point(75, 342);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(116, 17);
            this.label4.TabIndex = 4;
            this.label4.Text = "Seating capacity:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label5.Location = new System.Drawing.Point(75, 364);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(93, 17);
            this.label5.TabIndex = 5;
            this.label5.Text = "Product year:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label6.Location = new System.Drawing.Point(75, 386);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(87, 17);
            this.label6.TabIndex = 6;
            this.label6.Text = "Engine type:";
            // 
            // lbDoorsDetail
            // 
            this.lbDoorsDetail.AutoSize = true;
            this.lbDoorsDetail.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lbDoorsDetail.Location = new System.Drawing.Point(224, 298);
            this.lbDoorsDetail.Name = "lbDoorsDetail";
            this.lbDoorsDetail.Size = new System.Drawing.Size(0, 17);
            this.lbDoorsDetail.TabIndex = 8;
            // 
            // lbTranssionsTypeDetail
            // 
            this.lbTranssionsTypeDetail.AutoSize = true;
            this.lbTranssionsTypeDetail.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lbTranssionsTypeDetail.Location = new System.Drawing.Point(224, 320);
            this.lbTranssionsTypeDetail.Name = "lbTranssionsTypeDetail";
            this.lbTranssionsTypeDetail.Size = new System.Drawing.Size(0, 17);
            this.lbTranssionsTypeDetail.TabIndex = 9;
            // 
            // lbSeatingCapacityDetail
            // 
            this.lbSeatingCapacityDetail.AutoSize = true;
            this.lbSeatingCapacityDetail.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lbSeatingCapacityDetail.Location = new System.Drawing.Point(224, 342);
            this.lbSeatingCapacityDetail.Name = "lbSeatingCapacityDetail";
            this.lbSeatingCapacityDetail.Size = new System.Drawing.Size(0, 17);
            this.lbSeatingCapacityDetail.TabIndex = 10;
            // 
            // lbProductYearDetail
            // 
            this.lbProductYearDetail.AutoSize = true;
            this.lbProductYearDetail.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lbProductYearDetail.Location = new System.Drawing.Point(224, 364);
            this.lbProductYearDetail.Name = "lbProductYearDetail";
            this.lbProductYearDetail.Size = new System.Drawing.Size(0, 17);
            this.lbProductYearDetail.TabIndex = 11;
            // 
            // lbEngineTypeDetail
            // 
            this.lbEngineTypeDetail.AutoSize = true;
            this.lbEngineTypeDetail.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lbEngineTypeDetail.Location = new System.Drawing.Point(224, 386);
            this.lbEngineTypeDetail.Name = "lbEngineTypeDetail";
            this.lbEngineTypeDetail.Size = new System.Drawing.Size(0, 17);
            this.lbEngineTypeDetail.TabIndex = 12;
            // 
            // frmCarSpecs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(560, 485);
            this.Controls.Add(this.lbEngineTypeDetail);
            this.Controls.Add(this.lbProductYearDetail);
            this.Controls.Add(this.lbSeatingCapacityDetail);
            this.Controls.Add(this.lbTranssionsTypeDetail);
            this.Controls.Add(this.lbDoorsDetail);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pbCarSpecs);
            this.Name = "frmCarSpecs";
            this.Text = "Car Specs";
            this.Load += new System.EventHandler(this.frmCarSpecs_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbCarSpecs)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbCarSpecs;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lbDoorsDetail;
        private System.Windows.Forms.Label lbTranssionsTypeDetail;
        private System.Windows.Forms.Label lbSeatingCapacityDetail;
        private System.Windows.Forms.Label lbProductYearDetail;
        private System.Windows.Forms.Label lbEngineTypeDetail;
    }
}