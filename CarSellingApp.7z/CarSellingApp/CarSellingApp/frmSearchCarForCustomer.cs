﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CarSellingApp
{
    public partial class frmSearchCarForCustomer : Form
    {
        int searchingType = 0;
        public frmSearchCarForCustomer()
        {
            InitializeComponent();
        }

        public static DataTable SearchByCarName(string carname)
        {
            SqlConnection cnn = new SqlConnection();
            frmSearchCar.connect(cnn);
            using (SqlCommand cmd = new SqlCommand("SELECT carID,carName,manufactureName,price,category FROM carsForSale join manufactures on carsForSale.manufactureCode = manufactures.manufactureCode WHERE carName like '%'+ @carName +'%'", cnn))
            {
                cmd.Parameters.AddWithValue("@carname", carname);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
        }
        public static DataTable SearchByManufacture(string manufacture)
        {
            SqlConnection cnn = new SqlConnection();
            frmSearchCar.connect(cnn);
            using (SqlCommand cmd = new SqlCommand("SELECT carID,carName,manufactureName,price,category FROM carsForSale join manufactures on carsForSale.manufactureCode = manufactures.manufactureCode WHERE manufactureName like '%'+ @manufacture +'%'", cnn))
            {
                cmd.Parameters.AddWithValue("@manufacture", manufacture);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
        }

        public static DataTable SearchByPrice(int price)
        {
            SqlConnection cnn = new SqlConnection();
            frmSearchCar.connect(cnn);
            using (SqlCommand cmd = new SqlCommand("SELECT carID,carName,manufactureName,price,category FROM carsForSale join manufactures on carsForSale.manufactureCode = manufactures.manufactureCode WHERE price <= @price ", cnn))
            {
                cmd.Parameters.AddWithValue("@price", price);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
        }

       

        private void dgvResult_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvResult.Rows[e.RowIndex];
                SqlConnection cnn = new SqlConnection();
                frmSearchCar.connect(cnn);
                using (SqlCommand cmd = new SqlCommand("SELECT image FROM carsForSale WHERE carName='" + row.Cells["CarName"].Value.ToString() + "'", cnn))
                {
                    if (cmd.ExecuteScalar() != null)
                    {
                        //show picture on pop-up form
                        SqlCommand SCmdCarSpec = new SqlCommand("SELECT * FROM carsSpecification WHERE carID ='" + row.Cells["ID"].Value.ToString() + "'", cnn);
                        SqlDataAdapter da = new SqlDataAdapter(SCmdCarSpec);
                        DataTable dt = new DataTable();
                        da.Fill(dt);

                        using (Form form = new frmCarSpecs(cmd.ExecuteScalar().ToString(), dt))
                        {
                            form.StartPosition = FormStartPosition.CenterScreen;

                            form.ShowDialog();
                        }
                        cnn.Close();
                        return;
                    }
                    else
                        MessageBox.Show("Not Found! ");

                }
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtKeyword.TextLength == 0)
                {
                    SqlConnection cnn = new SqlConnection();
                    frmSearchCar.connect(cnn);
                    using (SqlCommand cmd = new SqlCommand("SELECT carID,carName,manufactureName,price,category FROM carsForSale join manufactures on carsForSale.manufactureCode = manufactures.manufactureCode", cnn))
                    {
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        dgvResult.DataSource = dt;
                    }
                }
                else
                {
                    if (searchingType == 0)
                        MessageBox.Show("Choose a type to find!");
                    else
                    {

                        switch (searchingType)
                        {
                            case 1:
                                {
                                    dgvResult.DataSource = SearchByCarName(txtKeyword.Text);
                                    break;
                                }
                            case 2:
                                {
                                    dgvResult.DataSource = SearchByManufacture(txtKeyword.Text);
                                    break;
                                }
                            case 3:
                                {
                                    dgvResult.DataSource = SearchByPrice(int.Parse(txtKeyword.Text));
                                    break;
                                }
                        }
                    }

                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Please re-Enter true format! ");
            }
        }

        private void rbtnCarName_CheckedChanged(object sender, EventArgs e)
        {
            if (rbtnCarName.Checked == true)
                searchingType = 1;
        }

        private void rbtnCarModel_CheckedChanged(object sender, EventArgs e)
        {
            if (rbtnCarModel.Checked == true)
                searchingType = 2;
        }

        private void rbtbPrice_CheckedChanged(object sender, EventArgs e)
        {
            if (rbtbPrice.Checked == true)
                searchingType = 3;
        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmLogin newFrmLogin = new frmLogin();
            newFrmLogin.Show();
        }
    }
}
