﻿namespace CarSellingApp
{
    partial class frmNewOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbSoldCar = new System.Windows.Forms.GroupBox();
            this.dgvListOfSoldCars = new System.Windows.Forms.DataGridView();
            this.paymentID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CarID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CustomerID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SellerID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SoldDay = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.total = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gbInformation = new System.Windows.Forms.GroupBox();
            this.cbSeller = new System.Windows.Forms.ComboBox();
            this.lbSeller = new System.Windows.Forms.Label();
            this.cbCar = new System.Windows.Forms.ComboBox();
            this.lbSoldCar = new System.Windows.Forms.Label();
            this.cbCustomer = new System.Windows.Forms.ComboBox();
            this.txtID = new System.Windows.Forms.TextBox();
            this.dtSoldDay = new System.Windows.Forms.DateTimePicker();
            this.lbID = new System.Windows.Forms.Label();
            this.lbCustomer = new System.Windows.Forms.Label();
            this.lbSoldDay = new System.Windows.Forms.Label();
            this.gbFunctions = new System.Windows.Forms.GroupBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnXuat = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.lbTotal = new System.Windows.Forms.Label();
            this.gbSoldCar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListOfSoldCars)).BeginInit();
            this.gbInformation.SuspendLayout();
            this.gbFunctions.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbSoldCar
            // 
            this.gbSoldCar.Controls.Add(this.dgvListOfSoldCars);
            this.gbSoldCar.Location = new System.Drawing.Point(45, 238);
            this.gbSoldCar.Name = "gbSoldCar";
            this.gbSoldCar.Size = new System.Drawing.Size(549, 216);
            this.gbSoldCar.TabIndex = 31;
            this.gbSoldCar.TabStop = false;
            this.gbSoldCar.Text = "List Of Sold Cars";
            // 
            // dgvListOfSoldCars
            // 
            this.dgvListOfSoldCars.AllowUserToAddRows = false;
            this.dgvListOfSoldCars.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvListOfSoldCars.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dgvListOfSoldCars.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvListOfSoldCars.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.paymentID,
            this.CarID,
            this.CustomerID,
            this.SellerID,
            this.SoldDay,
            this.total});
            this.dgvListOfSoldCars.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dgvListOfSoldCars.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvListOfSoldCars.Location = new System.Drawing.Point(6, 19);
            this.dgvListOfSoldCars.MultiSelect = false;
            this.dgvListOfSoldCars.Name = "dgvListOfSoldCars";
            this.dgvListOfSoldCars.ReadOnly = true;
            this.dgvListOfSoldCars.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvListOfSoldCars.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvListOfSoldCars.Size = new System.Drawing.Size(543, 198);
            this.dgvListOfSoldCars.TabIndex = 0;
            this.dgvListOfSoldCars.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvListOfSoldCars_CellClick);
            // 
            // paymentID
            // 
            this.paymentID.DataPropertyName = "ID";
            this.paymentID.HeaderText = "PaymentID";
            this.paymentID.Name = "paymentID";
            this.paymentID.ReadOnly = true;
            // 
            // CarID
            // 
            this.CarID.DataPropertyName = "carID";
            this.CarID.HeaderText = "CarID";
            this.CarID.Name = "CarID";
            this.CarID.ReadOnly = true;
            this.CarID.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.CarID.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // CustomerID
            // 
            this.CustomerID.DataPropertyName = "customerID";
            this.CustomerID.HeaderText = "CustomerID";
            this.CustomerID.Name = "CustomerID";
            this.CustomerID.ReadOnly = true;
            this.CustomerID.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.CustomerID.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // SellerID
            // 
            this.SellerID.DataPropertyName = "employeeID";
            this.SellerID.HeaderText = "Seller";
            this.SellerID.Name = "SellerID";
            this.SellerID.ReadOnly = true;
            this.SellerID.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.SellerID.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // SoldDay
            // 
            this.SoldDay.DataPropertyName = "soldDay";
            this.SoldDay.HeaderText = "Sold Day";
            this.SoldDay.Name = "SoldDay";
            this.SoldDay.ReadOnly = true;
            // 
            // total
            // 
            this.total.DataPropertyName = "total";
            this.total.HeaderText = "Total";
            this.total.Name = "total";
            this.total.ReadOnly = true;
            // 
            // gbInformation
            // 
            this.gbInformation.Controls.Add(this.cbSeller);
            this.gbInformation.Controls.Add(this.lbSeller);
            this.gbInformation.Controls.Add(this.cbCar);
            this.gbInformation.Controls.Add(this.lbSoldCar);
            this.gbInformation.Controls.Add(this.cbCustomer);
            this.gbInformation.Controls.Add(this.txtID);
            this.gbInformation.Controls.Add(this.dtSoldDay);
            this.gbInformation.Controls.Add(this.lbID);
            this.gbInformation.Controls.Add(this.lbCustomer);
            this.gbInformation.Controls.Add(this.lbSoldDay);
            this.gbInformation.Location = new System.Drawing.Point(45, 63);
            this.gbInformation.Name = "gbInformation";
            this.gbInformation.Size = new System.Drawing.Size(316, 160);
            this.gbInformation.TabIndex = 29;
            this.gbInformation.TabStop = false;
            this.gbInformation.Text = "Enter Information";
            // 
            // cbSeller
            // 
            this.cbSeller.FormattingEnabled = true;
            this.cbSeller.Location = new System.Drawing.Point(122, 102);
            this.cbSeller.Name = "cbSeller";
            this.cbSeller.Size = new System.Drawing.Size(177, 21);
            this.cbSeller.TabIndex = 7;
            // 
            // lbSeller
            // 
            this.lbSeller.AutoSize = true;
            this.lbSeller.Location = new System.Drawing.Point(13, 104);
            this.lbSeller.Name = "lbSeller";
            this.lbSeller.Size = new System.Drawing.Size(33, 13);
            this.lbSeller.TabIndex = 6;
            this.lbSeller.Text = "Seller";
            // 
            // cbCar
            // 
            this.cbCar.FormattingEnabled = true;
            this.cbCar.Location = new System.Drawing.Point(122, 48);
            this.cbCar.Name = "cbCar";
            this.cbCar.Size = new System.Drawing.Size(177, 21);
            this.cbCar.TabIndex = 5;
            this.cbCar.SelectedIndexChanged += new System.EventHandler(this.cbCar_SelectedIndexChanged);
            // 
            // lbSoldCar
            // 
            this.lbSoldCar.AutoSize = true;
            this.lbSoldCar.Location = new System.Drawing.Point(13, 50);
            this.lbSoldCar.Name = "lbSoldCar";
            this.lbSoldCar.Size = new System.Drawing.Size(23, 13);
            this.lbSoldCar.TabIndex = 4;
            this.lbSoldCar.Text = "Car";
            // 
            // cbCustomer
            // 
            this.cbCustomer.FormattingEnabled = true;
            this.cbCustomer.Location = new System.Drawing.Point(122, 75);
            this.cbCustomer.Name = "cbCustomer";
            this.cbCustomer.Size = new System.Drawing.Size(177, 21);
            this.cbCustomer.TabIndex = 3;
            // 
            // txtID
            // 
            this.txtID.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtID.Location = new System.Drawing.Point(122, 22);
            this.txtID.Name = "txtID";
            this.txtID.ReadOnly = true;
            this.txtID.Size = new System.Drawing.Size(177, 20);
            this.txtID.TabIndex = 1;
            this.txtID.Text = "AUTO";
            this.txtID.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // dtSoldDay
            // 
            this.dtSoldDay.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtSoldDay.Location = new System.Drawing.Point(122, 129);
            this.dtSoldDay.Name = "dtSoldDay";
            this.dtSoldDay.Size = new System.Drawing.Size(177, 20);
            this.dtSoldDay.TabIndex = 2;
            // 
            // lbID
            // 
            this.lbID.AutoSize = true;
            this.lbID.Location = new System.Drawing.Point(13, 28);
            this.lbID.Name = "lbID";
            this.lbID.Size = new System.Drawing.Size(18, 13);
            this.lbID.TabIndex = 0;
            this.lbID.Text = "ID";
            // 
            // lbCustomer
            // 
            this.lbCustomer.AutoSize = true;
            this.lbCustomer.Location = new System.Drawing.Point(13, 77);
            this.lbCustomer.Name = "lbCustomer";
            this.lbCustomer.Size = new System.Drawing.Size(51, 13);
            this.lbCustomer.TabIndex = 0;
            this.lbCustomer.Text = "Customer";
            // 
            // lbSoldDay
            // 
            this.lbSoldDay.AutoSize = true;
            this.lbSoldDay.Location = new System.Drawing.Point(13, 130);
            this.lbSoldDay.Name = "lbSoldDay";
            this.lbSoldDay.Size = new System.Drawing.Size(48, 13);
            this.lbSoldDay.TabIndex = 0;
            this.lbSoldDay.Text = "Sold day";
            // 
            // gbFunctions
            // 
            this.gbFunctions.Controls.Add(this.btnDelete);
            this.gbFunctions.Controls.Add(this.btnXuat);
            this.gbFunctions.Controls.Add(this.btnAdd);
            this.gbFunctions.Location = new System.Drawing.Point(381, 128);
            this.gbFunctions.Name = "gbFunctions";
            this.gbFunctions.Size = new System.Drawing.Size(213, 95);
            this.gbFunctions.TabIndex = 30;
            this.gbFunctions.TabStop = false;
            this.gbFunctions.Text = "Functions";
            // 
            // btnDelete
            // 
            this.btnDelete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnDelete.Location = new System.Drawing.Point(6, 50);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(87, 23);
            this.btnDelete.TabIndex = 5;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnXuat
            // 
            this.btnXuat.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnXuat.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXuat.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnXuat.Location = new System.Drawing.Point(114, 18);
            this.btnXuat.Name = "btnXuat";
            this.btnXuat.Size = new System.Drawing.Size(83, 55);
            this.btnXuat.TabIndex = 2;
            this.btnXuat.Text = "Export Bill";
            this.btnXuat.UseVisualStyleBackColor = true;
            this.btnXuat.Click += new System.EventHandler(this.btnXuat_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnAdd.Location = new System.Drawing.Point(6, 19);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(87, 23);
            this.btnAdd.TabIndex = 0;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(240, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(192, 31);
            this.label2.TabIndex = 27;
            this.label2.Text = "NEW ORDER";
            // 
            // txtTotal
            // 
            this.txtTotal.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.txtTotal.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTotal.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.txtTotal.Location = new System.Drawing.Point(456, 81);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.Size = new System.Drawing.Size(122, 20);
            this.txtTotal.TabIndex = 32;
            // 
            // lbTotal
            // 
            this.lbTotal.AutoSize = true;
            this.lbTotal.Location = new System.Drawing.Point(384, 83);
            this.lbTotal.Name = "lbTotal";
            this.lbTotal.Size = new System.Drawing.Size(34, 13);
            this.lbTotal.TabIndex = 33;
            this.lbTotal.Text = "Total:";
            // 
            // frmNewOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(645, 481);
            this.Controls.Add(this.lbTotal);
            this.Controls.Add(this.txtTotal);
            this.Controls.Add(this.gbSoldCar);
            this.Controls.Add(this.gbInformation);
            this.Controls.Add(this.gbFunctions);
            this.Controls.Add(this.label2);
            this.Name = "frmNewOrder";
            this.Text = "New Order";
            this.Load += new System.EventHandler(this.frmCarSold_Load);
            this.gbSoldCar.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvListOfSoldCars)).EndInit();
            this.gbInformation.ResumeLayout(false);
            this.gbInformation.PerformLayout();
            this.gbFunctions.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox gbSoldCar;
        private System.Windows.Forms.DataGridView dgvListOfSoldCars;
        private System.Windows.Forms.GroupBox gbInformation;
        private System.Windows.Forms.ComboBox cbCustomer;
        private System.Windows.Forms.DateTimePicker dtSoldDay;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.Label lbID;
        private System.Windows.Forms.Label lbCustomer;
        private System.Windows.Forms.Label lbSoldDay;
        private System.Windows.Forms.GroupBox gbFunctions;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnXuat;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbSeller;
        private System.Windows.Forms.Label lbSeller;
        private System.Windows.Forms.ComboBox cbCar;
        private System.Windows.Forms.Label lbSoldCar;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.Label lbTotal;
        private System.Windows.Forms.DataGridViewTextBoxColumn paymentID;
        private System.Windows.Forms.DataGridViewTextBoxColumn CarID;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustomerID;
        private System.Windows.Forms.DataGridViewTextBoxColumn SellerID;
        private System.Windows.Forms.DataGridViewTextBoxColumn SoldDay;
        private System.Windows.Forms.DataGridViewTextBoxColumn total;
    }
}