﻿namespace CarSellingApp
{
    partial class frmBill
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.crptCarReceipt = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.rptPayment3 = new CarSellingApp.rptBill();
            this.rptPayment1 = new CarSellingApp.rptBill();
            this.rptPayment2 = new CarSellingApp.rptBill();
            this.SuspendLayout();
            // 
            // crptCarReceipt
            // 
            this.crptCarReceipt.ActiveViewIndex = 0;
            this.crptCarReceipt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.crptCarReceipt.Cursor = System.Windows.Forms.Cursors.Default;
            this.crptCarReceipt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.crptCarReceipt.Location = new System.Drawing.Point(0, 0);
            this.crptCarReceipt.Name = "crptCarReceipt";
            this.crptCarReceipt.ReportSource = this.rptPayment3;
            this.crptCarReceipt.Size = new System.Drawing.Size(745, 540);
            this.crptCarReceipt.TabIndex = 0;
            // 
            // frmBill
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(745, 540);
            this.Controls.Add(this.crptCarReceipt);
            this.Name = "frmBill";
            this.Text = "frmCarSaleReceipt";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);

        }

        #endregion

        private CrystalDecisions.Windows.Forms.CrystalReportViewer crptCarReceipt;
        private rptBill rptPayment1;
        private rptBill rptPayment2;
        private rptBill rptPayment3;
    }
}