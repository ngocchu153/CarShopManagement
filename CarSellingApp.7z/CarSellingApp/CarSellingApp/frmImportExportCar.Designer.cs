﻿namespace CarSellingApp
{
    partial class frmImportExportCar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnUpdate = new System.Windows.Forms.Button();
            this.txtExportQuantity = new System.Windows.Forms.TextBox();
            this.lblQuantity = new System.Windows.Forms.Label();
            this.dgvImportExport = new System.Windows.Forms.DataGridView();
            this.lbManageCustomers = new System.Windows.Forms.Label();
            this.cbCar = new System.Windows.Forms.ComboBox();
            this.lbSoldCar = new System.Windows.Forms.Label();
            this.txtImportQuantity = new System.Windows.Forms.TextBox();
            this.lbImport = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvImportExport)).BeginInit();
            this.SuspendLayout();
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(176, 188);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(75, 23);
            this.btnUpdate.TabIndex = 16;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // txtExportQuantity
            // 
            this.txtExportQuantity.Location = new System.Drawing.Point(113, 150);
            this.txtExportQuantity.Name = "txtExportQuantity";
            this.txtExportQuantity.Size = new System.Drawing.Size(138, 20);
            this.txtExportQuantity.TabIndex = 15;
            // 
            // lblQuantity
            // 
            this.lblQuantity.AutoSize = true;
            this.lblQuantity.Location = new System.Drawing.Point(12, 155);
            this.lblQuantity.Name = "lblQuantity";
            this.lblQuantity.Size = new System.Drawing.Size(82, 13);
            this.lblQuantity.TabIndex = 12;
            this.lblQuantity.Text = "Export Quantity:";
            // 
            // dgvImportExport
            // 
            this.dgvImportExport.AllowUserToAddRows = false;
            this.dgvImportExport.AllowUserToDeleteRows = false;
            this.dgvImportExport.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvImportExport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvImportExport.Location = new System.Drawing.Point(294, 90);
            this.dgvImportExport.Name = "dgvImportExport";
            this.dgvImportExport.ReadOnly = true;
            this.dgvImportExport.Size = new System.Drawing.Size(279, 148);
            this.dgvImportExport.TabIndex = 9;
            this.dgvImportExport.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
             // 
            // lbManageCustomers
            // 
            this.lbManageCustomers.AutoSize = true;
            this.lbManageCustomers.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbManageCustomers.ForeColor = System.Drawing.Color.Blue;
            this.lbManageCustomers.Location = new System.Drawing.Point(202, 26);
            this.lbManageCustomers.Name = "lbManageCustomers";
            this.lbManageCustomers.Size = new System.Drawing.Size(190, 31);
            this.lbManageCustomers.TabIndex = 29;
            this.lbManageCustomers.Text = "Import/Export";
            // 
            // cbCar
            // 
            this.cbCar.FormattingEnabled = true;
            this.cbCar.Location = new System.Drawing.Point(113, 90);
            this.cbCar.Name = "cbCar";
            this.cbCar.Size = new System.Drawing.Size(138, 21);
            this.cbCar.TabIndex = 31;
            // 
            // lbSoldCar
            // 
            this.lbSoldCar.AutoSize = true;
            this.lbSoldCar.Location = new System.Drawing.Point(13, 90);
            this.lbSoldCar.Name = "lbSoldCar";
            this.lbSoldCar.Size = new System.Drawing.Size(26, 13);
            this.lbSoldCar.TabIndex = 30;
            this.lbSoldCar.Text = "Car:";
            // 
            // txtImportQuantity
            // 
            this.txtImportQuantity.Location = new System.Drawing.Point(113, 121);
            this.txtImportQuantity.Name = "txtImportQuantity";
            this.txtImportQuantity.Size = new System.Drawing.Size(138, 20);
            this.txtImportQuantity.TabIndex = 33;
            // 
            // lbImport
            // 
            this.lbImport.AutoSize = true;
            this.lbImport.Location = new System.Drawing.Point(12, 122);
            this.lbImport.Name = "lbImport";
            this.lbImport.Size = new System.Drawing.Size(81, 13);
            this.lbImport.TabIndex = 32;
            this.lbImport.Text = "Import Quantity:";
            // 
            // frmImportExportCar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(586, 268);
            this.Controls.Add(this.txtImportQuantity);
            this.Controls.Add(this.lbImport);
            this.Controls.Add(this.cbCar);
            this.Controls.Add(this.lbSoldCar);
            this.Controls.Add(this.lbManageCustomers);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.txtExportQuantity);
            this.Controls.Add(this.lblQuantity);
            this.Controls.Add(this.dgvImportExport);
            this.Name = "frmImportExportCar";
            this.Text = "frmImportExportCar";
            this.Load += new System.EventHandler(this.frmImportExportCar_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvImportExport)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.TextBox txtExportQuantity;
        private System.Windows.Forms.Label lblQuantity;
        private System.Windows.Forms.DataGridView dgvImportExport;
        private System.Windows.Forms.Label lbManageCustomers;
        private System.Windows.Forms.ComboBox cbCar;
        private System.Windows.Forms.Label lbSoldCar;
        private System.Windows.Forms.TextBox txtImportQuantity;
        private System.Windows.Forms.Label lbImport;
    }
}