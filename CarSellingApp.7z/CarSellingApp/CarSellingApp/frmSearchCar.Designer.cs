﻿namespace CarSellingApp
{
    partial class frmSearchCar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rbtbCategory = new System.Windows.Forms.RadioButton();
            this.btnSearch = new System.Windows.Forms.Button();
            this.rbtnCarModel = new System.Windows.Forms.RadioButton();
            this.rbtnCarName = new System.Windows.Forms.RadioButton();
            this.lbKeyword = new System.Windows.Forms.Label();
            this.groupBoxFind = new System.Windows.Forms.GroupBox();
            this.txtKeyword = new System.Windows.Forms.TextBox();
            this.groupBoxResult = new System.Windows.Forms.GroupBox();
            this.dgvResult = new System.Windows.Forms.DataGridView();
            this.lbSearchCar = new System.Windows.Forms.Label();
            this.price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.category = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CarName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Manufacture = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBoxFind.SuspendLayout();
            this.groupBoxResult.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResult)).BeginInit();
            this.SuspendLayout();
            // 
            // rbtbCategory
            // 
            this.rbtbCategory.AutoSize = true;
            this.rbtbCategory.Location = new System.Drawing.Point(379, 83);
            this.rbtbCategory.Name = "rbtbCategory";
            this.rbtbCategory.Size = new System.Drawing.Size(67, 17);
            this.rbtbCategory.TabIndex = 6;
            this.rbtbCategory.TabStop = true;
            this.rbtbCategory.Text = "Category";
            this.rbtbCategory.UseVisualStyleBackColor = true;
            this.rbtbCategory.CheckedChanged += new System.EventHandler(this.rbtbCategory_CheckedChanged);
            // 
            // btnSearch
            // 
            this.btnSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSearch.Location = new System.Drawing.Point(481, 32);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(65, 25);
            this.btnSearch.TabIndex = 2;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnFind_Click);
            // 
            // rbtnCarModel
            // 
            this.rbtnCarModel.AutoSize = true;
            this.rbtnCarModel.Location = new System.Drawing.Point(270, 83);
            this.rbtnCarModel.Name = "rbtnCarModel";
            this.rbtnCarModel.Size = new System.Drawing.Size(85, 17);
            this.rbtnCarModel.TabIndex = 5;
            this.rbtnCarModel.TabStop = true;
            this.rbtnCarModel.Text = "Manufacture";
            this.rbtnCarModel.UseVisualStyleBackColor = true;
            this.rbtnCarModel.CheckedChanged += new System.EventHandler(this.rbtnCarModel_CheckedChanged);
            // 
            // rbtnCarName
            // 
            this.rbtnCarName.AutoSize = true;
            this.rbtnCarName.Location = new System.Drawing.Point(163, 83);
            this.rbtnCarName.Name = "rbtnCarName";
            this.rbtnCarName.Size = new System.Drawing.Size(72, 17);
            this.rbtnCarName.TabIndex = 4;
            this.rbtnCarName.TabStop = true;
            this.rbtnCarName.Text = "Car Name";
            this.rbtnCarName.UseVisualStyleBackColor = true;
            this.rbtnCarName.CheckedChanged += new System.EventHandler(this.rbtnCarName_CheckedChanged);
            // 
            // lbKeyword
            // 
            this.lbKeyword.AutoSize = true;
            this.lbKeyword.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbKeyword.Location = new System.Drawing.Point(51, 32);
            this.lbKeyword.Name = "lbKeyword";
            this.lbKeyword.Size = new System.Drawing.Size(84, 24);
            this.lbKeyword.TabIndex = 0;
            this.lbKeyword.Text = "Keyword";
            // 
            // groupBoxFind
            // 
            this.groupBoxFind.Controls.Add(this.rbtbCategory);
            this.groupBoxFind.Controls.Add(this.rbtnCarModel);
            this.groupBoxFind.Controls.Add(this.rbtnCarName);
            this.groupBoxFind.Controls.Add(this.txtKeyword);
            this.groupBoxFind.Controls.Add(this.lbKeyword);
            this.groupBoxFind.Controls.Add(this.btnSearch);
            this.groupBoxFind.Location = new System.Drawing.Point(61, 66);
            this.groupBoxFind.Name = "groupBoxFind";
            this.groupBoxFind.Size = new System.Drawing.Size(592, 134);
            this.groupBoxFind.TabIndex = 5;
            this.groupBoxFind.TabStop = false;
            this.groupBoxFind.Text = "Find";
            // 
            // txtKeyword
            // 
            this.txtKeyword.Location = new System.Drawing.Point(163, 35);
            this.txtKeyword.Name = "txtKeyword";
            this.txtKeyword.Size = new System.Drawing.Size(283, 20);
            this.txtKeyword.TabIndex = 1;
            this.txtKeyword.TextChanged += new System.EventHandler(this.txtKeyword_TextChanged);
            // 
            // groupBoxResult
            // 
            this.groupBoxResult.Controls.Add(this.dgvResult);
            this.groupBoxResult.Cursor = System.Windows.Forms.Cursors.Hand;
            this.groupBoxResult.Location = new System.Drawing.Point(61, 216);
            this.groupBoxResult.Name = "groupBoxResult";
            this.groupBoxResult.Size = new System.Drawing.Size(595, 228);
            this.groupBoxResult.TabIndex = 6;
            this.groupBoxResult.TabStop = false;
            this.groupBoxResult.Text = "List of Result";
            // 
            // dgvResult
            // 
            this.dgvResult.AllowUserToAddRows = false;
            this.dgvResult.AllowUserToDeleteRows = false;
            this.dgvResult.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvResult.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvResult.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.Manufacture,
            this.CarName,
            this.quantity,
            this.category,
            this.price});
            this.dgvResult.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dgvResult.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvResult.Location = new System.Drawing.Point(3, 16);
            this.dgvResult.Name = "dgvResult";
            this.dgvResult.ReadOnly = true;
            this.dgvResult.Size = new System.Drawing.Size(589, 209);
            this.dgvResult.TabIndex = 0;
            this.dgvResult.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvResult_CellMouseClick);
            // 
            // lbSearchCar
            // 
            this.lbSearchCar.AutoSize = true;
            this.lbSearchCar.Font = new System.Drawing.Font("Microsoft Sans Serif", 27F);
            this.lbSearchCar.ForeColor = System.Drawing.Color.Blue;
            this.lbSearchCar.Location = new System.Drawing.Point(254, 23);
            this.lbSearchCar.Name = "lbSearchCar";
            this.lbSearchCar.Size = new System.Drawing.Size(253, 40);
            this.lbSearchCar.TabIndex = 4;
            this.lbSearchCar.Text = "SEARCH CAR";
            // 
            // price
            // 
            this.price.DataPropertyName = "price";
            this.price.HeaderText = "Price";
            this.price.Name = "price";
            this.price.ReadOnly = true;
            // 
            // category
            // 
            this.category.DataPropertyName = "category";
            this.category.HeaderText = "Category";
            this.category.Name = "category";
            this.category.ReadOnly = true;
            // 
            // quantity
            // 
            this.quantity.DataPropertyName = "quantity";
            this.quantity.HeaderText = "Quatity";
            this.quantity.Name = "quantity";
            this.quantity.ReadOnly = true;
            // 
            // CarName
            // 
            this.CarName.DataPropertyName = "carName";
            this.CarName.HeaderText = "Car Name";
            this.CarName.Name = "CarName";
            this.CarName.ReadOnly = true;
            // 
            // Manufacture
            // 
            this.Manufacture.DataPropertyName = "manufactureName";
            this.Manufacture.HeaderText = "Manufacture";
            this.Manufacture.Name = "Manufacture";
            this.Manufacture.ReadOnly = true;
            // 
            // ID
            // 
            this.ID.DataPropertyName = "carID";
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            // 
            // frmSearchCar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(726, 465);
            this.Controls.Add(this.groupBoxFind);
            this.Controls.Add(this.groupBoxResult);
            this.Controls.Add(this.lbSearchCar);
            this.Name = "frmSearchCar";
            this.Text = "Find Car";
            this.Load += new System.EventHandler(this.frmFindCar_Load);
            this.groupBoxFind.ResumeLayout(false);
            this.groupBoxFind.PerformLayout();
            this.groupBoxResult.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvResult)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.RadioButton rbtbCategory;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.RadioButton rbtnCarModel;
        private System.Windows.Forms.RadioButton rbtnCarName;
        private System.Windows.Forms.Label lbKeyword;
        private System.Windows.Forms.GroupBox groupBoxFind;
        private System.Windows.Forms.TextBox txtKeyword;
        private System.Windows.Forms.GroupBox groupBoxResult;
        private System.Windows.Forms.DataGridView dgvResult;
        private System.Windows.Forms.Label lbSearchCar;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Manufacture;
        private System.Windows.Forms.DataGridViewTextBoxColumn CarName;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn category;
        private System.Windows.Forms.DataGridViewTextBoxColumn price;
    }
}