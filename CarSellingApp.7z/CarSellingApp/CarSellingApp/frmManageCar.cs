﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace CarSellingApp
{
    public partial class frmManageCar : Form
    {
        public frmManageCar()
        {
            InitializeComponent();
            display();
        }

        protected void fillManufactureCB()
        {
            SqlConnection cnn = new SqlConnection();
            frmSearchCar.connect(cnn);
            DataSet ds = new DataSet();
            try
            {
                SqlCommand cmd = new SqlCommand("select manufactureCode,manufactureName from manufactures", cnn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                cbManufacture.DisplayMember = "manufactureName";
                cbManufacture.ValueMember = "manufactureCode";
                cbManufacture.DataSource = ds.Tables[0];
            }
            catch (Exception)
            {
                //Exception Message
            }
            finally
            {
                cbManufacture.SelectedIndex = -1;
                cbManufacture.Text = ("-Select a manufacture-");
                cnn.Close();
            }
        }

        private void display()
        {
            SqlConnection cnn = new SqlConnection();
            frmSearchCar.connect(cnn);

            //tab Car
            string carTab = "SELECT carID,carName,manufactureName,price,quantity,category,image FROM carsForSale join manufactures on carsForSale.manufactureCode = manufactures.manufactureCode";
            SqlCommand cmd = new SqlCommand(carTab, cnn);
            cmd.CommandType = CommandType.Text;
            SqlDataAdapter data = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            data.Fill(dt);
           
            //tab Manufacture
            fillManufactureCB();
            dgvResult.DataSource = dt;
            string manuTab = "Select * from manufactures";
            cmd = new SqlCommand(manuTab, cnn);
            cmd.CommandType = CommandType.Text;
            data = new SqlDataAdapter(cmd);
            dt = new DataTable();
            data.Fill(dt);
            dgvManufacture.DataSource = dt;

            //tab CarSpecs
            string carSpecs = "SELECT * FROM carsSpecification";
            cmd = new SqlCommand(carSpecs, cnn);
            cmd.CommandType = CommandType.Text;
            data = new SqlDataAdapter(cmd);
            dt = new DataTable();
            data.Fill(dt);
            dgvCarSpecs.DataSource = dt;
                
            cnn.Close();
        }
        
        private void dgvResult_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvResult.Rows[e.RowIndex];
                txtCarID.Text = row.Cells["ID"].Value.ToString();
                txtCarName.Text = row.Cells["CarName"].Value.ToString();
                txtCategory.Text = row.Cells["Category"].Value.ToString();
                cbManufacture.Text = row.Cells["Manufacture"].Value.ToString();
                txtPrice.Text = row.Cells["Price"].Value.ToString();
                txtQuantity.Text = row.Cells["Quantity"].Value.ToString();
                txtImageLink.Text = row.Cells["Image"].Value.ToString();
            }
        }

        private void btnAddCar_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection cnn = new SqlConnection();
                frmSearchCar.connect(cnn);

                string addCommand = "insert into carsForSale(carName,category,quantity,manufactureCode,price,image) values (@carname, @category ,@quantity, @manufactureCode, @price, @image)";
                SqlCommand cmd = new SqlCommand(addCommand, cnn);
                cmd.Parameters.AddWithValue("@carname", txtCarName.Text);
                cmd.Parameters.AddWithValue("@category", txtCategory.Text);
                cmd.Parameters.AddWithValue("@quantity", int.Parse(txtQuantity.Text));
                cmd.Parameters.AddWithValue("@price", int.Parse(txtPrice.Text));
                cmd.Parameters.AddWithValue("@manufactureCode", cbManufacture.SelectedValue.ToString());
                cmd.Parameters.AddWithValue("@image", txtImageLink.Text);

                cmd.ExecuteNonQuery();
                display();
                cnn.Close();
                MessageBox.Show("Car added!");

           }
            catch (Exception)
            {
                MessageBox.Show("Cant Add!");
            }
        }

        private void btnDeleteCar_Click(object sender, EventArgs e)
        {
            SqlConnection cnn = new SqlConnection();
            frmSearchCar.connect(cnn);

            string deleteCmd = "delete from carsForSale where carID = '" + txtCarID.Text + "'";
            SqlCommand cmd = new SqlCommand(deleteCmd, cnn);
            DialogResult result = MessageBox.Show("Do you want to delete ?", "!!!", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (result == DialogResult.OK)
                cmd.ExecuteNonQuery();
            MessageBox.Show("Car deleted!");

            display();
            cnn.Close();
        }

        private void btnUpdateCar_Click(object sender, EventArgs e)
        {
            SqlConnection cnn = new SqlConnection();
            frmSearchCar.connect(cnn);
            string updateCmd = "Update carsForSale set carName = @carname,category=@category, quantity=@quantity , price = @price, manufactureCode = @manufactureCode, image = @image where carID ='"+txtCarID.Text+"'";
            SqlCommand cmd = new SqlCommand(updateCmd, cnn);
            cmd.Parameters.AddWithValue("@carname", txtCarName.Text);
            cmd.Parameters.AddWithValue("@category", txtCategory.Text);
            cmd.Parameters.AddWithValue("@quantity", int.Parse(txtQuantity.Text));
            cmd.Parameters.AddWithValue("@price", int.Parse(txtPrice.Text));
            cmd.Parameters.AddWithValue("@image", txtImageLink.Text );
            cmd.Parameters.AddWithValue("@manufactureCode", cbManufacture.SelectedValue.ToString());

            cmd.ExecuteNonQuery();

            MessageBox.Show("Car updated!");

            display();
            cnn.Close();
        }

        private void gbCarInfomation_Enter(object sender, EventArgs e)
        {

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtCarID.Text = "";
            txtCarName.Text = "";
            txtCategory.Text = "";
            txtPrice.Text = "";
            txtQuantity.Text = "";
            txtImageLink.Text = "";
            cbManufacture.Text = "";
        }

        private void btnChooseImage_Click(object sender, EventArgs e)
        {
            OpenFileDialog openDialog = new OpenFileDialog();
            openDialog.Filter = "Image Files (.png; .jpg )|*.png; *.jpg";
            openDialog.ShowDialog();
            string sFileName = openDialog.FileName;
            if (sFileName != "")
                txtImageLink.Text = Path.GetFullPath(sFileName);
            return;
            

        }

        private void dgvManufacture_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvManufacture.Rows[e.RowIndex];

                txtManuCode.Text = row.Cells["code"].Value.ToString();
                txtManuName.Text = row.Cells["name"].Value.ToString();
                
            }
        }

        private void btnAddManufacture_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection cnn = new SqlConnection();
                frmSearchCar.connect(cnn);

                string addCommand = "insert into manufactures values (@code, @name)";
                SqlCommand cmd = new SqlCommand(addCommand, cnn);
                cmd.Parameters.AddWithValue("@code", txtManuCode.Text);
                cmd.Parameters.AddWithValue("@name", txtManuName.Text);

                cmd.ExecuteNonQuery();
                display();
                cnn.Close();
                MessageBox.Show("Manufature added!");

            }
            catch (SqlException)
            {
                MessageBox.Show("Can not Add!");
            }
}

        private void btnDeleteManufacture_Click(object sender, EventArgs e)
        {
            SqlConnection cnn = new SqlConnection();
            frmSearchCar.connect(cnn);
            try
            {
                string deleteCmd = "delete from manufactures where manufactureCode = '" + txtManuCode.Text + "'";
                SqlCommand cmd = new SqlCommand(deleteCmd, cnn);
                DialogResult result = MessageBox.Show("Do you want to delete ?", "!!!", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                if (result == DialogResult.OK)
                    cmd.ExecuteNonQuery();
                MessageBox.Show("Manufacture deleted!");
            }
            catch (SqlException)
            {
                MessageBox.Show("Can not delete!");
            }
            display();
            cnn.Close();
        }

        private void btnUpdateManufacture_Click(object sender, EventArgs e)
        {
            SqlConnection cnn = new SqlConnection();
            frmSearchCar.connect(cnn);
            try
            {
                string updateCmd = "Update manufactures set manufactureCode = @code, manufactureName=@name where manufactureCode ='" + txtManuCode.Text + "'";
                SqlCommand cmd = new SqlCommand(updateCmd, cnn);
                cmd.Parameters.AddWithValue("@code", txtManuCode.Text);
                cmd.Parameters.AddWithValue("@name", txtManuName.Text);

                cmd.ExecuteNonQuery();

                MessageBox.Show("Manufacture updated!");
            }
            catch (SqlException)
            {
                MessageBox.Show("Can not update this manufacture because of FK relationship");
            }
            finally
            {
                display();
                cnn.Close();
            }
        }

        private void dgvCarSpecs_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvCarSpecs.Rows[e.RowIndex];

                txtCarSpecsID.Text = row.Cells["carID"].Value.ToString();
                txtDoorsNumber.Text = row.Cells["doorsNumber"].Value.ToString();
                txtTransmissionType.Text = row.Cells["transmissionType"].Value.ToString();
                txtSeatingCapacity.Text = row.Cells["seatingCapacity"].Value.ToString();
                txtProductYear.Text = row.Cells["productYear"].Value.ToString();
                txtEngineType.Text = row.Cells["engineType"].Value.ToString();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtCarID.Text))
            {
                tabControl.SelectedIndex = 2;
                String searchValue = txtCarID.Text;
                int rowIndex = -1;
                foreach (DataGridViewRow row in dgvCarSpecs.Rows)
                {
                    if (row.Cells[0].Value.ToString().Equals(searchValue))
                    {
                        rowIndex = row.Index;
                        break;
                    }
                }
                txtCarSpecsID.Text = txtCarID.Text;
                txtDoorsNumber.Text = "";
                txtTransmissionType.Text = "";
                txtSeatingCapacity.Text = "";
                txtProductYear.Text = "";
                txtEngineType.Text = "";

                if (rowIndex>-1) {
                    DataGridViewRow selectedRow = this.dgvCarSpecs.Rows[rowIndex];

                    txtDoorsNumber.Text = selectedRow.Cells["doorsNumber"].Value.ToString();
                    txtTransmissionType.Text = selectedRow.Cells["transmissionType"].Value.ToString();
                    txtSeatingCapacity.Text = selectedRow.Cells["seatingCapacity"].Value.ToString();
                    txtProductYear.Text = selectedRow.Cells["productYear"].Value.ToString();
                    txtEngineType.Text = selectedRow.Cells["engineType"].Value.ToString();
                }
            }
        }

        private void lbManageManufacture_Click(object sender, EventArgs e)
        {

        }

        private void btnAddCarSpecs_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection connection = new SqlConnection();
                frmSearchCar.connect(connection);
                string addCmd = "insert into carsSpecification(doorsNumber,transmissionType,seatingCapacity,productYear,engineType) values (@doorsNumber,@transmissionType,@seatingCapacity,@productYear,@engineType)";
                SqlCommand cmd = new SqlCommand(addCmd, connection);
                cmd.Parameters.AddWithValue("@doorsNumber", Int32.Parse(txtDoorsNumber.Text));
                cmd.Parameters.AddWithValue("@transmissionType", txtTransmissionType.Text);
                cmd.Parameters.AddWithValue("@seatingCapacity", Int32.Parse(txtSeatingCapacity.Text));
                cmd.Parameters.AddWithValue("@productYear", Int32.Parse(txtProductYear.Text));
                cmd.Parameters.AddWithValue("@engineType", txtEngineType.Text);

                cmd.ExecuteNonQuery();
                connection.Close();

                MessageBox.Show("added");
            }
            catch (SqlException)
            {
                MessageBox.Show("Can not add");
            }
            finally
            {
                display();
            }
        }

        private void btnDeleteCarSpecs_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection connection = new SqlConnection();
                frmSearchCar.connect(connection);
                string delCmd = "delete from carsSpecification where carID = '" + txtCarSpecsID.Text + "'";
                SqlCommand cmd = new SqlCommand(delCmd, connection);
                DialogResult result = MessageBox.Show("Do you want to delete?", "Delete", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                if (result == DialogResult.OK)
                    cmd.ExecuteNonQuery();
                connection.Close();

                MessageBox.Show("Deleted");
            }
            catch (SqlException)
            {
                MessageBox.Show("Can not delete");
            }
            finally
            {
                display(); 
            }
        }

        private void btnUpdateCarSpecs_Click(object sender, EventArgs e)
        {

            try
            {
                SqlConnection connection = new SqlConnection();
                frmSearchCar.connect(connection); 
                string uptCmd = "update carsSpecification set doorsNumber = @doorsNumber, transmissionType = @transmissionType, seatingCapacity = @seatingCapacity, productYear = @productYear, engineType = @engineType where carID= '" + txtCarSpecsID.Text + "'";
                SqlCommand cmd = new SqlCommand(uptCmd, connection);
                cmd.Parameters.AddWithValue("@doorsNumber", Int32.Parse(txtDoorsNumber.Text));
                cmd.Parameters.AddWithValue("@transmissionType", txtTransmissionType.Text);
                cmd.Parameters.AddWithValue("@seatingCapacity", Int32.Parse(txtSeatingCapacity.Text));
                cmd.Parameters.AddWithValue("@productYear", Int32.Parse(txtProductYear.Text));
                cmd.Parameters.AddWithValue("@engineType", txtEngineType.Text);

                cmd.ExecuteNonQuery();
                connection.Close();

                MessageBox.Show("Updated");
            }
            catch (SqlException)
            {
                MessageBox.Show("Can not update");
            }
            finally
            {
                display();
            }
        }
    }
}
