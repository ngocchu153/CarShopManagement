﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarSellingApp
{
    public partial class frmMenu : Form
    {
        public frmMenu()
        {
            InitializeComponent();
        }

        private void btnFindCar_Click(object sender, EventArgs e)
        {
            frmSearchCar frmFind = new frmSearchCar();
            frmFind.Show();
        }

        private void btnManageCar_Click(object sender, EventArgs e)
        {
            frmManageCar frmManageCar = new frmManageCar();
            frmManageCar.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmNewOrder frmSold = new frmNewOrder();
            frmSold.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmManageEmployees fr = new frmManageEmployees();
            fr.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            frmManageCustomers fr = new frmManageCustomers();
            fr.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            frmImportExportCar fr = new frmImportExportCar();
            fr.Show();
        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmLogin newFrmLogin = new frmLogin();
            newFrmLogin.Show();
        }

        private void btnExportRevenueReport_Click(object sender, EventArgs e)
        {
            frmRevenueReport frmNewRevenueRP = new frmRevenueReport();
            frmNewRevenueRP.Show();
        }

        private void frmMenu_Load(object sender, EventArgs e)
        {

        }

        private void frmMenu_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
