﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace CarSellingApp
{
    public partial class frmNewOrder : Form
    {
        public frmNewOrder()
        {
            InitializeComponent();
        }



        private void fillDataCBCar()
        {
            SqlConnection cnn = new SqlConnection();
            frmSearchCar.connect(cnn);
            DataSet ds = new DataSet();
            try
            {
                SqlCommand cmd = new SqlCommand("select carID, carName from carsForSale", cnn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                cbCar.DisplayMember = "carName";
                cbCar.ValueMember = "carID";
                cbCar.DataSource = ds.Tables[0];

            }
            catch (Exception)
            {
                MessageBox.Show("   ");
            }
            finally
            {
                cbCar.SelectedIndex = -1;
                cbCar.Text = ("-Select a car-");
                cnn.Close();
            }
        }

        private void fillDataCBCustomer()
        {
            SqlConnection cnn = new SqlConnection();
            frmSearchCar.connect(cnn);
            DataSet ds = new DataSet();
            try
            {
                SqlCommand cmd = new SqlCommand("select customerID, customerName from customers", cnn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                cbCustomer.DisplayMember = "customerName";
                cbCustomer.ValueMember = "customerID";
                cbCustomer.DataSource = ds.Tables[0];

            }
            catch (Exception)
            {
                MessageBox.Show("   ");
            }
            finally
            {
                cbCustomer.SelectedIndex = -1;
                cbCustomer.Text = ("-Select a customer-");
                cnn.Close();
            }
        }

        private void fillDataCBSeller()
        {

            SqlConnection cnn = new SqlConnection();
            frmSearchCar.connect(cnn);
            DataSet ds = new DataSet();
            try
            {
                SqlCommand cmd = new SqlCommand("select employeeID, employeeName from employees", cnn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                cbSeller.DisplayMember = "employeeName";
                cbSeller.ValueMember = "employeeID";
                cbSeller.DataSource = ds.Tables[0];

            }
            catch (Exception)
            {
                MessageBox.Show("   ");
            }
            finally
            {
                cbSeller.SelectedIndex = -1;
                cbSeller.Text = ("-Select a seller-");
                cnn.Close();
            }
        }

        private void displayListOfSoldCars()
        {
            SqlConnection cnn = new SqlConnection();
            frmSearchCar.connect(cnn);
            DataSet ds = new DataSet();
            try
            {
                SqlCommand cmd = new SqlCommand("select * from payment", cnn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                dgvListOfSoldCars.DataSource = ds.Tables[0];

            }
            catch (Exception)
            {
                MessageBox.Show("   ");
            }
        }

        private void frmCarSold_Load(object sender, EventArgs e)
        {
            fillDataCBCar();
            fillDataCBCustomer();
            fillDataCBSeller();
            displayListOfSoldCars();

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {

            try
            {
                SqlConnection cnn = new SqlConnection();
                frmSearchCar.connect(cnn);

                string addCommand = "insert into payment (customerID,employeeID,soldDay,carID,total) values ( @customerID ,@employeeID, @soldDay, @carID,@total)";
                SqlCommand cmd = new SqlCommand(addCommand, cnn);

                cmd.Parameters.AddWithValue("@customerID", int.Parse(cbCustomer.SelectedValue.ToString()));
                cmd.Parameters.AddWithValue("@employeeID", (cbSeller.SelectedValue.ToString()));
                cmd.Parameters.AddWithValue("@soldDay", dtSoldDay.Value);
                cmd.Parameters.AddWithValue("@carID", cbCar.SelectedValue);
                cmd.Parameters.AddWithValue("@total", int.Parse(txtTotal.Text));

                cmd.ExecuteNonQuery();
                displayListOfSoldCars();
                cnn.Close();

                MessageBox.Show("Added!");

            }
            catch (Exception)
            {
                MessageBox.Show("Can not Add!");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            SqlConnection cnn = new SqlConnection();
            frmSearchCar.connect(cnn);

            string deleteCmd = "delete from carsForSale where ID = '" + txtID.Text + "'";
            SqlCommand cmd = new SqlCommand(deleteCmd, cnn);
            DialogResult result = MessageBox.Show("Are you sure want to delete ?", "!!!", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (result == DialogResult.OK)
            {
                cmd.ExecuteNonQuery();
                MessageBox.Show("Deleted!");
            }
            displayListOfSoldCars();
            cnn.Close();
        }

        private void dgvListOfSoldCars_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvListOfSoldCars.Rows[e.RowIndex];

                txtID.Text = row.Cells["paymentID"].Value.ToString();
                cbCar.SelectedValue = row.Cells["CarID"].Value.ToString();
                cbCustomer.SelectedValue = row.Cells["CustomerID"].Value.ToString();
                cbSeller.SelectedValue = row.Cells["SellerID"].Value.ToString(); ;
                dtSoldDay.Value = Convert.ToDateTime(row.Cells["soldDay"].Value.ToString());
                cbSeller.SelectedValue = row.Cells["SellerID"].Value.ToString(); ;

            }
        }

        private void cbCar_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbCar.SelectedIndex > -1)
            {
                string total;
                SqlConnection cnn = new SqlConnection();
                frmSearchCar.connect(cnn);
                using (SqlCommand cmd = new SqlCommand("SELECT price FROM carsForSale WHERE carID = @carID ", cnn))
                {
                    cmd.Parameters.AddWithValue("@carID", cbCar.SelectedValue);

                    total = (cmd.ExecuteScalar().ToString());

                }
                txtTotal.Text = total;
            }
        }

        private void btnXuat_Click(object sender, EventArgs e)
        {
            frmBill frmNewBill  = new frmBill();
            frmNewBill.Show();
        }
    }
}
