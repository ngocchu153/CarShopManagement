﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarSellingApp
{
    public partial class frmCarSpecs : Form
    {
        public frmCarSpecs()
        {
            InitializeComponent();
        }

        public frmCarSpecs(string imageLink,DataTable dt)
        {

            InitializeComponent();
            pbCarSpecs.Image = Image.FromFile(imageLink);
            if (dt.Rows.Count > 0)
            {
                DataRow row = dt.Rows[0];

                lbDoorsDetail.Text = row["doorsNumber"].ToString();
                lbTranssionsTypeDetail.Text = row["transmissionType"].ToString();
                lbSeatingCapacityDetail.Text = row["seatingCapacity"].ToString();
                lbProductYearDetail.Text = row["productYear"].ToString();
                lbEngineTypeDetail.Text = row["engineType"].ToString();
            }
        }

        private void frmCarSpecs_Load(object sender, EventArgs e)
        {

        }
    }
}
