﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CarSellingApp
{
    public partial class frmManageEmployees : Form
    {
        public frmManageEmployees()
        {
            InitializeComponent();
            Display();
        }
        
           

        private void backToManagementToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        } 
        
        private void Display()
        {
            SqlConnection connection = new SqlConnection();
            frmSearchCar.connect(connection);
            DataTable dt = new DataTable();
            SqlCommand cmd = new SqlCommand("Select * from employees", connection);
            SqlDataAdapter adt = new SqlDataAdapter(cmd);
            adt.Fill(dt);

            dataGridView1.DataSource = dt;
            connection.Close();
        }
        private void Clear()
        {
            txtEmpID.Text = "";
            txtEmpName.Text = "";
        }
        

        private void btnInsert_Click_1(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection();
            frmSearchCar.connect(connection);
            string s = "Insert into employees(employeeName) values (@employeeName)";
            SqlCommand cmd = new SqlCommand(s, connection);
            cmd.Parameters.AddWithValue("@employeeName", txtEmpName.Text);
            cmd.ExecuteNonQuery();
            connection.Close();
            Clear();
            Display();
        }

        private void btnDelete_Click_1(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection();
            frmSearchCar.connect(connection);
            string DelCmd = "Delete from employees where employeeID= '" + dataGridView1.CurrentRow.Cells["employeeID"].Value.ToString() + "'";
            SqlCommand cmd = new SqlCommand(DelCmd, connection);
            DialogResult result = MessageBox.Show("Do you want to delete?", "Delete", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (result == DialogResult.OK)
                cmd.ExecuteNonQuery();
            connection.Close();
            Display();
            Clear();
        }

        private void btnUpdate_Click_1(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection();
            frmSearchCar.connect(connection);
            string UpdCmd = "Update employees set employeeName = @employeeName where employeeID ='" + txtEmpID.Text + "'";
            SqlCommand cmd = new SqlCommand(UpdCmd, connection);
            cmd.Parameters.AddWithValue("@employeeID", txtEmpID.Text);
            cmd.Parameters.AddWithValue("@employeeName", txtEmpName.Text);
            cmd.ExecuteNonQuery();
            connection.Close();
            Display();
            Clear();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtEmpID.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtEmpName.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
        }
    }
}
